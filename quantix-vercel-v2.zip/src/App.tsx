/**
 * Quantix UI — Production-Ready Admin Analytics Hub
 * ─────────────────────────────────────────────────
 * Fixed:  Favicon 404, all form id/name/htmlFor, all button type="button",
 *         aria-labels on icon-only buttons, role="button"+tabIndex on
 *         interactive divs, React key prop warnings, header search a11y,
 *         CSV anchor cleanup, dangerouslySetInnerHTML sanitisation,
 *         aria-expanded on dropdowns, aria-live on toast, meta tags,
 *         window.confirm replaced with inline confirmation, semantic nav/header.
 */

import { useState, useEffect, useRef, useCallback } from "react";
import { Sun, Moon, Bell } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend
} from "recharts";

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const MOCK_USER = {
  email: "admin@quantix.io",
  password: "admin123",
  name: "Alex Morgan",
  role: "Super Admin",
  company: "Quantix Labs",
};

const revenueData = [
  { month: "Jan", revenue: 42000, expenses: 28000 },
  { month: "Feb", revenue: 55000, expenses: 32000 },
  { month: "Mar", revenue: 48000, expenses: 29000 },
  { month: "Apr", revenue: 61000, expenses: 35000 },
  { month: "May", revenue: 73000, expenses: 38000 },
  { month: "Jun", revenue: 68000, expenses: 41000 },
  { month: "Jul", revenue: 82000, expenses: 44000 },
];

const trafficData = [
  { day: "Mon", organic: 3200, paid: 1800, direct: 900 },
  { day: "Tue", organic: 2800, paid: 2200, direct: 1100 },
  { day: "Wed", organic: 4100, paid: 1900, direct: 800 },
  { day: "Thu", organic: 3700, paid: 2500, direct: 1400 },
  { day: "Fri", organic: 4800, paid: 2100, direct: 1200 },
  { day: "Sat", organic: 2100, paid: 1200, direct: 600 },
  { day: "Sun", organic: 1800, paid: 900, direct: 500 },
];

const pieData = [
  { name: "Enterprise", value: 38, color: "#6366f1" },
  { name: "Pro",        value: 29, color: "#8b5cf6" },
  { name: "Starter",   value: 21, color: "#a78bfa" },
  { name: "Free",      value: 12, color: "#c4b5fd" },
];

const aiUsageData = [
  { week: "W1", queries: 12400, tokens: 8200 },
  { week: "W2", queries: 15800, tokens: 11200 },
  { week: "W3", queries: 13200, tokens: 9400 },
  { week: "W4", queries: 18900, tokens: 14200 },
  { week: "W5", queries: 22100, tokens: 17800 },
  { week: "W6", queries: 19500, tokens: 15200 },
];

const initialLeads = [
  { id: 1, name: "Sarah Chen",      company: "Vertex Corp",    email: "s.chen@vertex.io",     status: "Hot",       value: 48000, date: "2024-07-15" },
  { id: 2, name: "James Whitfield", company: "Meridian Labs",  email: "j.white@meridian.com", status: "Warm",      value: 23500, date: "2024-07-12" },
  { id: 3, name: "Priya Nair",      company: "Solaris AI",     email: "p.nair@solaris.ai",    status: "Cold",      value: 12000, date: "2024-07-10" },
  { id: 4, name: "Marcus Reyes",    company: "Cobalt Tech",    email: "m.reyes@cobalt.tech",  status: "Hot",       value: 67000, date: "2024-07-08" },
  { id: 5, name: "Elena Vasquez",   company: "Neon Digital",   email: "e.vasquez@neon.io",    status: "Warm",      value: 31000, date: "2024-07-05" },
  { id: 6, name: "Tom Nakamura",    company: "Pulse Systems",  email: "t.naka@pulse.sys",     status: "Qualified", value: 55000, date: "2024-07-03" },
];

const initialProjects = [
  { id: 1, name: "Quantix Analytics v2",   status: "In Progress", progress: 72, team: ["AK","SR","MJ"],     due: "Aug 15", priority: "High" },
  { id: 2, name: "Mobile App Redesign",    status: "Review",      progress: 91, team: ["PL","TR"],           due: "Jul 28", priority: "Critical" },
  { id: 3, name: "API Gateway Migration",  status: "In Progress", progress: 44, team: ["NK","BJ","CR","LM"], due: "Sep 02", priority: "Medium" },
  { id: 4, name: "Customer Portal",        status: "Planning",    progress: 18, team: ["AM","DS"],           due: "Sep 30", priority: "Low" },
];

const initialKanban = {
  todo:       [
    { id: "t1", title: "Research competitor analytics", tag: "Research", priority: "Medium" },
    { id: "t2", title: "Design new onboarding flow",   tag: "Design",   priority: "High" },
    { id: "t3", title: "Update API documentation",     tag: "Docs",     priority: "Low" },
  ],
  inprogress: [
    { id: "t4", title: "Build reporting module", tag: "Dev",     priority: "High" },
    { id: "t5", title: "QA testing sprint 4",    tag: "Testing", priority: "Critical" },
  ],
  review: [
    { id: "t6", title: "Accessibility audit", tag: "QA", priority: "Medium" },
  ],
  done: [
    { id: "t7", title: "Set up CI/CD pipeline",          tag: "DevOps",   priority: "High" },
    { id: "t8", title: "User interviews (12 sessions)",  tag: "Research", priority: "Medium" },
  ],
};

const initialEmails = {
  inbox: [
    { id: "e1", from: "Sarah Chen",   subject: "Q3 Proposal Follow-up",          preview: "Hi, just checking in on the proposal we discussed…",           date: "10:32 AM", read: false, starred: false },
    { id: "e2", from: "Stripe",       subject: "Your invoice is ready",           preview: "Invoice #INV-2024-0847 for $1,240.00 is now available…",       date: "9:15 AM",  read: false, starred: false },
    { id: "e3", from: "Marcus Reyes", subject: "Partnership opportunity",         preview: "We'd love to explore a potential integration between…",         date: "Yesterday", read: true,  starred: true },
    { id: "e4", from: "GitHub",       subject: "Security alert on quantix-api",  preview: "A vulnerability was detected in one of your dependencies…",    date: "Yesterday", read: true,  starred: false },
  ],
  sent:    [],
  drafts:  [],
  starred: [],
  trash:   [],
};

const initialNotifications = [
  { id: 1, text: "New lead added: Sarah Chen from Vertex Corp",          time: "2m ago",  read: false, icon: "👤" },
  { id: 2, text: "Revenue target 85% achieved this month",              time: "1h ago",  read: false, icon: "📈" },
  { id: 3, text: "Project 'Mobile App Redesign' moved to Review",       time: "3h ago",  read: false, icon: "📋" },
  { id: 4, text: "New comment on Analytics Dashboard ticket",           time: "5h ago",  read: true,  icon: "💬" },
  { id: 5, text: "Scheduled maintenance: Sunday 2–4 AM UTC",            time: "1d ago",  read: true,  icon: "🔧" },
];

const chatConversations = [
  { id: "c1", title: "Revenue analysis deep dive", messages: [
    { role: "user", content: "Analyze our Q2 revenue trends and suggest improvements." },
    { role: "ai",   content: "Based on the data patterns, Q2 showed **18% growth** over Q1, primarily driven by enterprise tier upgrades. Key observations:\n\n1. **Enterprise segment** grew 31% — your highest performer\n2. **Churn rate** decreased from 4.2% to 2.8%\n3. **ARPU** increased by $24 MoM\n\nRecommended focus areas: expand enterprise upsell motions and invest in the onboarding flow to reduce time-to-value for new Pro users." },
  ]},
  { id: "c2", title: "Product roadmap planning", messages: [
    { role: "user", content: "Help me prioritize our product roadmap for Q4." },
    { role: "ai",   content: "For Q4 prioritization, I'd recommend using the **ICE framework** (Impact, Confidence, Effort).\n\nBased on your current metrics, the highest-priority items would be:\n\n- **AI-powered insights** — high demand, strong differentiation\n- **Mobile app** — 40% of users request this\n- **API v2** — unblocks 3 enterprise deals\n\nShall I create a detailed scoring matrix?" },
  ]},
];

// ─── STYLES ───────────────────────────────────────────────────────────────────
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:      #0a0b0f;
    --bg2:     #111318;
    --bg3:     #181c24;
    --bg4:     #1e2330;
    --border:  rgba(255,255,255,0.07);
    --border2: rgba(255,255,255,0.12);
    --text:    #e8eaf0;
    --text2:   #9097a8;
    --text3:   #636b7a;
    --accent:  #6366f1;
    --accent2: #8b5cf6;
    --accent3: #06b6d4;
    --green:   #10b981;
    --red:     #ef4444;
    --orange:  #f59e0b;
    --yellow:  #eab308;
    --glow:    rgba(99,102,241,0.15);
    --radius:  12px;
    --radius2: 8px;
    --sidebar: 240px;
    --header:  60px;
    --font:    'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    --mono:    'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace;
  }

  .light-mode {
    --bg:      #f0f2f7;
    --bg2:     #ffffff;
    --bg3:     #f8f9fc;
    --bg4:     #eef0f6;
    --border:  rgba(0,0,0,0.07);
    --border2: rgba(0,0,0,0.12);
    --text:    #1a1d27;
    --text2:   #4b5263;
    --text3:   #8a92a6;
    --glow:    rgba(99,102,241,0.08);
  }

  body { font-family: var(--font); background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.5; }

  /* Focus ring — keyboard accessibility */
  :focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
    border-radius: var(--radius2);
  }

  /* Scrollbar */
  ::-webkit-scrollbar { width: 4px; height: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 99px; }

  /* Skip link for screen readers */
  .skip-link {
    position: absolute; top: -100%; left: 8px;
    background: var(--accent); color: #fff; padding: 6px 12px;
    border-radius: var(--radius2); font-size: 13px; font-weight: 600;
    z-index: 9999; text-decoration: none;
  }
  .skip-link:focus { top: 8px; }

  /* Layout */
  .app-shell  { display: flex; min-height: 100vh; }
  .sidebar {
    width: var(--sidebar); height: 100vh; position: fixed; left: 0; top: 0; z-index: 100;
    background: var(--bg2); border-right: 1px solid var(--border);
    display: flex; flex-direction: column;
    transition: width 0.25s cubic-bezier(.4,0,.2,1), transform 0.25s cubic-bezier(.4,0,.2,1);
    overflow: hidden;
  }
  .sidebar.collapsed { width: 60px; }
  .sidebar.mobile-open { transform: translateX(0) !important; }
  .main-area { margin-left: var(--sidebar); flex: 1; display: flex; flex-direction: column; min-height: 100vh; transition: margin-left 0.25s cubic-bezier(.4,0,.2,1); }
  .main-area.collapsed { margin-left: 60px; }
  .site-header {
    height: var(--header); background: var(--bg2); border-bottom: 1px solid var(--border);
    display: flex; align-items: center; padding: 0 20px; gap: 12px;
    position: sticky; top: 0; z-index: 50;
  }
  .page-content { padding: 24px; flex: 1; }

  /* Sidebar branding */
  .sidebar-brand {
    height: var(--header); display: flex; align-items: center; padding: 0 16px; gap: 10px;
    border-bottom: 1px solid var(--border); flex-shrink: 0; overflow: hidden;
  }
  .brand-icon  { width: 32px; height: 32px; border-radius: 8px; flex-shrink: 0; background: linear-gradient(135deg, var(--accent), var(--accent2)); display: flex; align-items: center; justify-content: center; font-size: 16px; }
  .brand-name  { font-size: 15px; font-weight: 800; white-space: nowrap; letter-spacing: -0.3px; }
  .brand-tag   { font-size: 9px; font-weight: 600; color: var(--accent); background: var(--glow); border: 1px solid rgba(99,102,241,0.2); border-radius: 4px; padding: 1px 5px; letter-spacing: 0.5px; white-space: nowrap; }

  /* Nav */
  .nav-section { padding: 12px 8px; flex: 1; overflow-y: auto; }
  .nav-label   { font-size: 9px; font-weight: 700; color: var(--text3); letter-spacing: 1px; padding: 8px 8px 4px; white-space: nowrap; overflow: hidden; }
  .nav-item {
    display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: var(--radius2);
    cursor: pointer; transition: all 0.15s; color: var(--text2); font-size: 13px; font-weight: 500;
    white-space: nowrap; overflow: hidden; position: relative; margin-bottom: 2px;
    background: none; border: none; width: 100%; text-align: left; font-family: var(--font);
  }
  .nav-item:hover { background: var(--bg3); color: var(--text); }
  .nav-item.active { background: var(--glow); color: var(--accent); }
  .nav-item.active::before { content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%); width: 3px; height: 60%; background: var(--accent); border-radius: 0 3px 3px 0; }
  .nav-icon  { width: 16px; flex-shrink: 0; text-align: center; font-size: 15px; }
  .nav-badge { margin-left: auto; background: var(--accent); color: white; font-size: 9px; font-weight: 700; border-radius: 99px; padding: 1px 6px; }

  /* Header elements */
  .h-spacer     { flex: 1; }
  .h-search     { flex: 1; max-width: 320px; position: relative; }
  .h-search input { width: 100%; background: var(--bg3); border: 1px solid var(--border); border-radius: var(--radius2); padding: 7px 12px 7px 34px; font-size: 13px; color: var(--text); outline: none; font-family: var(--font); }
  .h-search input::placeholder { color: var(--text3); }
  .h-search-icon { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--text3); font-size: 13px; pointer-events: none; }
  .h-btn { width: 34px; height: 34px; border-radius: var(--radius2); background: var(--bg3); border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; cursor: pointer; position: relative; transition: all 0.15s; color: var(--text2); font-size: 15px; font-family: var(--font); }
  .h-btn:hover { background: var(--bg4); color: var(--text); }
  .badge-dot   { position: absolute; top: 5px; right: 5px; width: 8px; height: 8px; background: var(--accent); border-radius: 50%; border: 2px solid var(--bg2); }
  .badge-count { position: absolute; top: -4px; right: -4px; background: var(--red); color: white; font-size: 9px; font-weight: 700; border-radius: 99px; padding: 1px 5px; border: 2px solid var(--bg2); pointer-events: none; }
  .avatar { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--accent2)); display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: white; cursor: pointer; border: 2px solid var(--border2); background-clip: padding-box; }

  /* Dropdown */
  .dropdown { position: absolute; top: calc(100% + 8px); right: 0; background: var(--bg2); border: 1px solid var(--border2); border-radius: var(--radius); box-shadow: 0 16px 40px rgba(0,0,0,0.4); min-width: 240px; z-index: 200; overflow: hidden; animation: dropIn 0.15s ease; }
  @keyframes dropIn { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
  .dropdown-header  { padding: 12px 14px; border-bottom: 1px solid var(--border); }
  .dropdown-name    { font-weight: 700; font-size: 13px; }
  .dropdown-email   { font-size: 11px; color: var(--text3); margin-top: 1px; }
  .dropdown-item    { display: flex; align-items: center; gap: 10px; padding: 10px 14px; cursor: pointer; font-size: 13px; transition: background 0.1s; background: none; border: none; width: 100%; text-align: left; font-family: var(--font); color: var(--text); }
  .dropdown-item:hover { background: var(--bg3); }
  .dropdown-item.danger { color: var(--red); }
  .dropdown-divider { border: none; border-top: 1px solid var(--border); margin: 4px 0; }
  .notif-item { padding: 10px 14px; display: flex; gap: 10px; cursor: pointer; transition: background 0.1s; border-bottom: 1px solid var(--border); }
  .notif-item:hover { background: var(--bg3); }
  .notif-item.unread { background: rgba(99,102,241,0.05); }
  .notif-icon   { font-size: 18px; flex-shrink: 0; margin-top: 1px; }
  .notif-text   { font-size: 12px; line-height: 1.4; }
  .notif-time   { font-size: 10px; color: var(--text3); margin-top: 2px; }
  .notif-footer { padding: 10px 14px; text-align: center; font-size: 12px; color: var(--accent); cursor: pointer; background: none; border: none; width: 100%; font-family: var(--font); }
  .notif-footer:hover { background: var(--bg3); }

  /* Cards */
  .card    { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; }
  .card-sm { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; }
  .card-title { font-size: 14px; font-weight: 700; margin-bottom: 4px; }
  .card-sub   { font-size: 12px; color: var(--text2); }

  /* Grid */
  .grid-2    { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .grid-3    { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
  .grid-4    { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
  .grid-auto { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }

  /* KPI cards */
  .kpi          { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); padding: 18px 20px; position: relative; overflow: hidden; }
  .kpi::before  { content: ''; position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; border-radius: 50%; opacity: 0.08; }
  .kpi-accent::before { background: var(--accent); }
  .kpi-green::before  { background: var(--green); }
  .kpi-orange::before { background: var(--orange); }
  .kpi-cyan::before   { background: var(--accent3); }
  .kpi-label  { font-size: 11px; font-weight: 600; color: var(--text3); letter-spacing: 0.5px; text-transform: uppercase; }
  .kpi-value  { font-size: 26px; font-weight: 800; margin: 6px 0 4px; letter-spacing: -0.5px; }
  .kpi-change { font-size: 12px; font-weight: 600; display: flex; align-items: center; gap: 4px; }
  .kpi-change.up   { color: var(--green); }
  .kpi-change.down { color: var(--red); }
  .kpi-icon   { position: absolute; top: 16px; right: 16px; font-size: 22px; opacity: 0.6; }

  /* Page header */
  .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
  .page-title  { font-size: 20px; font-weight: 800; letter-spacing: -0.3px; }
  .page-sub    { font-size: 13px; color: var(--text2); margin-top: 2px; }

  /* Buttons */
  .btn         { display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; border-radius: var(--radius2); font-size: 13px; font-weight: 600; cursor: pointer; border: none; transition: all 0.15s; font-family: var(--font); }
  .btn-primary { background: var(--accent); color: white; }
  .btn-primary:hover { background: #4f46e5; }
  .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn-secondary { background: var(--bg3); color: var(--text); border: 1px solid var(--border2); }
  .btn-secondary:hover { background: var(--bg4); }
  .btn-secondary:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn-ghost  { background: transparent; color: var(--text2); }
  .btn-ghost:hover  { background: var(--bg3); color: var(--text); }
  .btn-danger { background: rgba(239,68,68,0.15); color: var(--red); border: 1px solid rgba(239,68,68,0.2); }
  .btn-danger:hover { background: rgba(239,68,68,0.25); }
  .btn-sm   { padding: 5px 10px; font-size: 12px; }
  .btn-xs   { padding: 3px 8px; font-size: 11px; }
  .btn-icon { padding: 7px; }

  /* Table */
  .table-wrap { overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; }
  th { font-size: 11px; font-weight: 700; color: var(--text3); text-transform: uppercase; letter-spacing: 0.5px; padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); white-space: nowrap; }
  td { padding: 12px 12px; border-bottom: 1px solid var(--border); font-size: 13px; vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tbody tr:hover { background: var(--bg3); }
  .clickable { cursor: pointer; }

  /* Badges */
  .badge           { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; }
  .badge-hot       { background: rgba(239,68,68,0.15);  color: var(--red); }
  .badge-warm      { background: rgba(245,158,11,0.15); color: var(--orange); }
  .badge-cold      { background: rgba(99,102,241,0.15); color: var(--accent); }
  .badge-qualified { background: rgba(16,185,129,0.15); color: var(--green); }
  .badge-in-progress { background: rgba(99,102,241,0.15); color: var(--accent); }
  .badge-review    { background: rgba(245,158,11,0.15); color: var(--orange); }
  .badge-done      { background: rgba(16,185,129,0.15); color: var(--green); }
  .badge-planning  { background: rgba(100,116,139,0.15); color: #94a3b8; }
  .badge-critical  { background: rgba(239,68,68,0.15);  color: var(--red); }
  .badge-high      { background: rgba(245,158,11,0.15); color: var(--orange); }
  .badge-medium    { background: rgba(99,102,241,0.15); color: var(--accent); }
  .badge-low       { background: rgba(16,185,129,0.15); color: var(--green); }

  /* Forms */
  .form-group  { margin-bottom: 14px; }
  .form-label  { display: block; font-size: 12px; font-weight: 600; color: var(--text2); margin-bottom: 5px; }
  .form-input  { width: 100%; background: var(--bg3); border: 1px solid var(--border2); border-radius: var(--radius2); padding: 9px 12px; font-size: 13px; color: var(--text); outline: none; font-family: var(--font); transition: border-color 0.15s; }
  .form-input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(99,102,241,0.15); }
  .form-input::placeholder { color: var(--text3); }
  .form-select { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%239097a8'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 10px center; padding-right: 28px; }
  .form-error  { font-size: 11px; color: var(--red); margin-top: 3px; }

  /* Modal */
  .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(4px); z-index: 500; display: flex; align-items: center; justify-content: center; padding: 20px; animation: fadeIn 0.15s ease; }
  @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  .modal { background: var(--bg2); border: 1px solid var(--border2); border-radius: 16px; width: 100%; max-width: 480px; max-height: 90vh; overflow-y: auto; animation: slideUp 0.2s ease; }
  @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
  .modal-lg     { max-width: 640px; }
  .modal-header { padding: 20px 20px 0; display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
  .modal-title  { font-size: 16px; font-weight: 800; }
  .modal-body   { padding: 0 20px; }
  .modal-footer { padding: 16px 20px 20px; display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid var(--border); margin-top: 16px; }

  /* Auth */
  .auth-page    { min-height: 100vh; background: var(--bg); display: flex; align-items: center; justify-content: center; padding: 20px; }
  .auth-card    { background: var(--bg2); border: 1px solid var(--border2); border-radius: 20px; padding: 36px; width: 100%; max-width: 400px; }
  .auth-logo    { display: flex; align-items: center; gap: 10px; margin-bottom: 28px; }
  .auth-title   { font-size: 22px; font-weight: 800; margin-bottom: 4px; }
  .auth-sub     { font-size: 13px; color: var(--text2); margin-bottom: 24px; }
  .auth-link    { color: var(--accent); cursor: pointer; font-weight: 600; background: none; border: none; font-family: var(--font); font-size: inherit; padding: 0; }
  .auth-link:hover { text-decoration: underline; }
  .auth-divider { display: flex; align-items: center; gap: 12px; margin: 16px 0; font-size: 12px; color: var(--text3); }
  .auth-divider::before, .auth-divider::after { content: ''; flex: 1; border-top: 1px solid var(--border); }
  .auth-error   { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); border-radius: var(--radius2); padding: 10px 12px; font-size: 13px; color: var(--red); margin-bottom: 14px; }
  .auth-success { background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.2); border-radius: var(--radius2); padding: 10px 12px; font-size: 13px; color: var(--green); margin-bottom: 14px; }

  /* Toast */
  .toast-container { position: fixed; bottom: 20px; right: 20px; z-index: 999; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
  .toast         { background: var(--bg2); border: 1px solid var(--border2); border-radius: var(--radius); padding: 12px 16px; font-size: 13px; box-shadow: 0 8px 24px rgba(0,0,0,0.3); display: flex; align-items: center; gap: 10px; min-width: 260px; animation: slideInRight 0.2s ease; pointer-events: auto; }
  @keyframes slideInRight { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
  .toast-success { border-left: 3px solid var(--green); }
  .toast-error   { border-left: 3px solid var(--red); }
  .toast-info    { border-left: 3px solid var(--accent); }

  /* Progress */
  .progress-bar  { height: 6px; background: var(--bg4); border-radius: 99px; overflow: hidden; }
  .progress-fill { height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent2)); border-radius: 99px; transition: width 0.6s cubic-bezier(.4,0,.2,1); }

  /* Calendar */
  .cal-grid       { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; }
  .cal-day-header { text-align: center; font-size: 11px; font-weight: 700; color: var(--text3); padding: 6px 0; text-transform: uppercase; letter-spacing: 0.5px; }
  .cal-cell       { min-height: 80px; background: var(--bg3); border-radius: var(--radius2); padding: 6px; border: 1px solid var(--border); cursor: pointer; transition: background 0.1s; }
  .cal-cell:hover { background: var(--bg4); }
  .cal-cell.today       { border-color: var(--accent); background: var(--glow); }
  .cal-cell.other-month { opacity: 0.35; }
  .cal-date  { font-size: 12px; font-weight: 600; margin-bottom: 4px; }
  .cal-event { background: var(--accent); color: white; border-radius: 3px; font-size: 10px; padding: 1px 4px; margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer; border: none; width: 100%; text-align: left; font-family: var(--font); }
  .cal-event:hover { opacity: 0.85; }

  /* Delete confirm inline */
  .cal-event-delete { background: rgba(239,68,68,0.85); color: white; border-radius: 3px; font-size: 10px; padding: 1px 4px; margin-bottom: 2px; display: flex; align-items: center; justify-content: space-between; gap: 4px; }
  .cal-event-delete button { background: none; border: none; color: white; cursor: pointer; font-size: 10px; padding: 0; font-family: var(--font); font-weight: 700; }

  /* Chat */
  .chat-layout   { display: flex; height: calc(100vh - var(--header) - 48px); }
  .chat-sidebar  { width: 220px; flex-shrink: 0; border-right: 1px solid var(--border); padding: 12px; overflow-y: auto; }
  .chat-main     { flex: 1; display: flex; flex-direction: column; }
  .chat-messages { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 16px; }
  .chat-msg      { display: flex; gap: 10px; max-width: 80%; }
  .chat-msg.user { flex-direction: row-reverse; align-self: flex-end; }
  .chat-bubble   { background: var(--bg3); border: 1px solid var(--border); border-radius: 12px; padding: 10px 14px; font-size: 13px; line-height: 1.6; }
  .chat-msg.user .chat-bubble { background: var(--accent); color: white; border-color: var(--accent); }
  .chat-msg .avatar { flex-shrink: 0; align-self: flex-start; }
  .chat-input-area { border-top: 1px solid var(--border); padding: 12px; }
  .chat-input-row  { display: flex; gap: 8px; align-items: flex-end; }
  .chat-input { flex: 1; background: var(--bg3); border: 1px solid var(--border2); border-radius: var(--radius); padding: 10px 14px; font-size: 13px; color: var(--text); outline: none; font-family: var(--font); resize: none; min-height: 42px; max-height: 120px; }
  .chat-input:focus { border-color: var(--accent); }
  .conv-item { padding: 8px 10px; border-radius: var(--radius2); cursor: pointer; font-size: 12px; font-weight: 500; transition: background 0.1s; margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; background: none; border: none; width: 100%; text-align: left; font-family: var(--font); color: var(--text2); }
  .conv-item:hover { background: var(--bg3); color: var(--text); }
  .conv-item.active { background: var(--glow); color: var(--accent); }
  .typing-indicator { display: flex; gap: 4px; align-items: center; padding: 8px 0; }
  .typing-dot { width: 6px; height: 6px; background: var(--text3); border-radius: 50%; animation: bounce 1.2s infinite; }
  .typing-dot:nth-child(2) { animation-delay: 0.2s; }
  .typing-dot:nth-child(3) { animation-delay: 0.4s; }
  @keyframes bounce { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-6px); } }

  /* Email */
  .email-layout  { display: flex; height: calc(100vh - var(--header) - 48px); }
  .email-sidebar { width: 180px; flex-shrink: 0; border-right: 1px solid var(--border); padding: 12px; }
  .email-list    { width: 300px; flex-shrink: 0; border-right: 1px solid var(--border); overflow-y: auto; }
  .email-view    { flex: 1; padding: 20px; overflow-y: auto; }
  .email-folder  { display: flex; align-items: center; gap: 8px; padding: 7px 10px; border-radius: var(--radius2); cursor: pointer; font-size: 13px; font-weight: 500; transition: background 0.1s; margin-bottom: 2px; background: none; border: none; width: 100%; font-family: var(--font); color: var(--text2); }
  .email-folder:hover { background: var(--bg3); color: var(--text); }
  .email-folder.active { background: var(--glow); color: var(--accent); }
  .email-item    { padding: 12px 14px; border-bottom: 1px solid var(--border); cursor: pointer; transition: background 0.1s; }
  .email-item:hover { background: var(--bg3); }
  .email-item.active { background: var(--glow); }
  .email-item.unread .email-from { font-weight: 700; }
  .email-from         { font-size: 13px; font-weight: 500; }
  .email-subject      { font-size: 12px; color: var(--text2); margin: 2px 0; }
  .email-preview-text { font-size: 11px; color: var(--text3); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .email-date         { font-size: 10px; color: var(--text3); }

  /* Kanban */
  .kanban-board { display: flex; gap: 16px; overflow-x: auto; padding-bottom: 8px; }
  .kanban-col   { width: 260px; flex-shrink: 0; background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); }
  .kanban-col-header { padding: 12px 14px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; font-size: 13px; font-weight: 700; }
  .kanban-cards { padding: 10px; min-height: 100px; display: flex; flex-direction: column; gap: 8px; }
  .kanban-card  { background: var(--bg3); border: 1px solid var(--border); border-radius: var(--radius2); padding: 12px; cursor: grab; transition: transform 0.15s, box-shadow 0.15s; }
  .kanban-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.2); }
  .kanban-card.dragging { opacity: 0.5; cursor: grabbing; }
  .kanban-card-title { font-size: 13px; font-weight: 600; margin-bottom: 8px; }

  /* Toggle */
  .toggle-group { display: flex; background: var(--bg3); border: 1px solid var(--border); border-radius: var(--radius2); overflow: hidden; }
  .toggle-btn   { padding: 6px 12px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.15s; color: var(--text2); background: none; border: none; font-family: var(--font); }
  .toggle-btn:hover { color: var(--text); background: var(--bg4); }
  .toggle-btn.active { background: var(--accent); color: white; }

  /* Settings */
  .settings-nav { display: flex; gap: 2px; padding: 4px; background: var(--bg3); border-radius: var(--radius); border: 1px solid var(--border); margin-bottom: 20px; }
  .settings-tab { padding: 7px 14px; border-radius: var(--radius2); font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.15s; color: var(--text2); background: none; border: none; font-family: var(--font); }
  .settings-tab.active { background: var(--bg2); color: var(--text); box-shadow: 0 1px 4px rgba(0,0,0,0.2); }

  /* Avatar upload */
  .avatar-upload { width: 72px; height: 72px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--accent2)); display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 700; color: white; cursor: pointer; position: relative; overflow: hidden; border: 3px solid var(--border2); }
  .avatar-upload:hover .avatar-overlay { opacity: 1; }
  .avatar-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; font-size: 18px; opacity: 0; transition: opacity 0.2s; }

  /* Pricing */
  .pricing-card { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; transition: border-color 0.2s; }
  .pricing-card:hover { border-color: var(--accent); }
  .pricing-card.recommended { border-color: var(--accent); background: var(--glow); }
  .pricing-price   { font-size: 28px; font-weight: 800; margin: 8px 0; }
  .pricing-period  { font-size: 12px; color: var(--text3); }
  .pricing-feature { display: flex; align-items: center; gap: 8px; font-size: 13px; padding: 4px 0; color: var(--text2); }

  /* Chart tabs */
  .chart-tabs { display: flex; gap: 6px; margin-bottom: 12px; }

  /* Misc utilities */
  .section-gap     { margin-bottom: 20px; }
  .flex            { display: flex; }
  .flex-col        { flex-direction: column; }
  .items-center    { align-items: center; }
  .justify-between { justify-content: space-between; }
  .gap-1  { gap: 4px; }
  .gap-2  { gap: 8px; }
  .gap-3  { gap: 12px; }
  .gap-4  { gap: 16px; }
  .mb-1   { margin-bottom: 4px; }
  .mb-2   { margin-bottom: 8px; }
  .mb-3   { margin-bottom: 12px; }
  .mb-4   { margin-bottom: 16px; }
  .mt-1   { margin-top: 4px; }
  .mt-2   { margin-top: 8px; }
  .mt-3   { margin-top: 12px; }
  .text-sm     { font-size: 12px; }
  .text-xs     { font-size: 11px; }
  .text-muted  { color: var(--text2); }
  .text-dim    { color: var(--text3); }
  .text-accent { color: var(--accent); }
  .text-green  { color: var(--green); }
  .text-red    { color: var(--red); }
  .font-bold     { font-weight: 700; }
  .font-semibold { font-weight: 600; }
  .w-full { width: 100%; }
  .hidden { display: none !important; }
  .relative { position: relative; }
  .overlay  { position: fixed; inset: 0; z-index: 90; }

  /* Responsive */
  @media (max-width: 1024px) {
    .grid-4 { grid-template-columns: repeat(2, 1fr); }
    .grid-3 { grid-template-columns: repeat(2, 1fr); }
  }
  @media (max-width: 768px) {
    .sidebar        { transform: translateX(-100%); z-index: 200; }
    .main-area      { margin-left: 0 !important; }
    .grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; }
    .page-content   { padding: 14px; }
    .chat-sidebar   { display: none; }
    .email-list     { display: none; }
    .email-sidebar  { width: 140px; }
    .kanban-board   { flex-direction: column; }
    .kanban-col     { width: 100%; }
    .h-search       { display: none; }
  }
  @media (max-width: 480px) {
    .auth-card { padding: 24px 20px; }
  }
`;

// ─── UTILITIES ────────────────────────────────────────────────────────────────
const fmt    = (n) => n >= 1000000 ? `$${(n/1000000).toFixed(1)}M` : n >= 1000 ? `$${(n/1000).toFixed(0)}K` : `$${n}`;
const fmtNum = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M`  : n >= 1000 ? `${(n/1000).toFixed(0)}K`  : String(n);
const uid    = () => Math.random().toString(36).slice(2, 9);

/** Sanitise AI markdown for safe innerHTML use — strips HTML then converts bold/newlines only. */
function renderMarkdown(text) {
  const escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  return escaped
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\n/g, "<br />");
}

/** Trigger a CSV download without leaving orphan DOM elements. */
function downloadCSV(csvContent, filename) {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ─── TOAST SYSTEM ─────────────────────────────────────────────────────────────
function useToast() {
  const [toasts, setToasts] = useState([]);
  const add = useCallback((msg, type = "success") => {
    const id = uid();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3500);
  }, []);
  return { toasts, add };
}

function ToastContainer({ toasts }) {
  return (
    <div
      className="toast-container"
      role="region"
      aria-live="polite"
      aria-label="Notifications"
    >
      {toasts.map(t => (
        <div key={t.id} className={`toast toast-${t.type}`} role="status">
          <span aria-hidden="true">
            {t.type === "success" ? "✅" : t.type === "error" ? "❌" : "ℹ️"}
          </span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

// ─── AUTH PAGES ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin, onNavigate }) {
  const [form, setForm]     = useState({ email: "", password: "" });
  const [error, setError]   = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = () => {
    if (!form.email || !form.password) { setError("Please fill in all fields."); return; }
    setLoading(true); setError("");
    setTimeout(() => {
      if (form.email === MOCK_USER.email && form.password === MOCK_USER.password) {
        onLogin();
      } else {
        setError("Invalid email or password."); setLoading(false);
      }
    }, 800);
  };

  return (
    <div className="auth-page">
      <div className="auth-card" role="main">
        <div className="auth-logo">
          <div className="brand-icon" aria-hidden="true">✦</div>
          <div>
            <div className="brand-name">Quantix UI</div>
            <div style={{ fontSize: 10, color: "var(--text3)" }}>Admin Analytics Hub</div>
          </div>
        </div>
        <h1 className="auth-title">Welcome back</h1>
        <p className="auth-sub">Sign in to your dashboard</p>
        {error && <div className="auth-error" role="alert">{error}</div>}
        <div className="form-group">
          <label className="form-label" htmlFor="login-email">Email address</label>
          <input
            id="login-email"
            name="email"
            className="form-input"
            type="email"
            placeholder="admin@quantix.io"
            autoComplete="email"
            value={form.email}
            onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
            onKeyDown={e => e.key === "Enter" && handleSubmit()}
          />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="login-password">Password</label>
          <input
            id="login-password"
            name="password"
            className="form-input"
            type="password"
            placeholder="••••••••"
            autoComplete="current-password"
            value={form.password}
            onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
            onKeyDown={e => e.key === "Enter" && handleSubmit()}
          />
        </div>
        <div style={{ textAlign: "right", marginBottom: 16 }}>
          <button type="button" className="auth-link text-sm" onClick={() => onNavigate("forgot")}>
            Forgot password?
          </button>
        </div>
        <button
          type="button"
          className="btn btn-primary w-full"
          onClick={handleSubmit}
          disabled={loading}
          style={{ justifyContent: "center", height: 40 }}
          aria-busy={loading}
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
        <div className="auth-divider" aria-hidden="true">or</div>
        <div className="text-sm" style={{ textAlign: "center", color: "var(--text2)" }}>
          Don't have an account?{" "}
          <button type="button" className="auth-link" onClick={() => onNavigate("register")}>
            Create one
          </button>
        </div>
        <div className="auth-success" style={{ marginTop: 16, marginBottom: 0 }}>
          <strong>Demo:</strong> admin@quantix.io / admin123
        </div>
      </div>
    </div>
  );
}

function RegisterPage({ onNavigate }) {
  const [form, setForm]       = useState({ name: "", email: "", password: "", confirm: "" });
  const [errors, setErrors]   = useState({});
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.name) e.name = "Name is required";
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = "Valid email required";
    if (!form.password || form.password.length < 6) e.password = "Min 6 characters";
    if (form.password !== form.confirm) e.confirm = "Passwords don't match";
    return e;
  };

  const handleSubmit = () => {
    const e = validate(); setErrors(e);
    if (Object.keys(e).length === 0) setSuccess(true);
  };

  const fieldMeta = [
    { key: "name",    label: "Full name",       type: "text",     ph: "Alex Morgan",    auto: "name" },
    { key: "email",   label: "Email address",   type: "email",    ph: "you@company.com",auto: "email" },
    { key: "password",label: "Password",        type: "password", ph: "••••••••",        auto: "new-password" },
    { key: "confirm", label: "Confirm password",type: "password", ph: "••••••••",        auto: "new-password" },
  ];

  if (success) return (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: "center" }} role="main">
        <div style={{ fontSize: 48, marginBottom: 16 }} aria-hidden="true">🎉</div>
        <h1 className="auth-title">Account created!</h1>
        <p className="auth-sub" style={{ marginBottom: 20 }}>Your account is ready. Sign in to continue.</p>
        <button type="button" className="btn btn-primary w-full" onClick={() => onNavigate("login")} style={{ justifyContent: "center" }}>
          Go to login
        </button>
      </div>
    </div>
  );

  return (
    <div className="auth-page">
      <div className="auth-card" role="main">
        <div className="auth-logo">
          <div className="brand-icon" aria-hidden="true">✦</div>
          <div className="brand-name">Quantix UI</div>
        </div>
        <h1 className="auth-title">Create account</h1>
        <p className="auth-sub">Start your 14-day free trial</p>
        {fieldMeta.map(f => (
          <div className="form-group" key={f.key}>
            <label className="form-label" htmlFor={`reg-${f.key}`}>{f.label}</label>
            <input
              id={`reg-${f.key}`}
              name={f.key}
              className="form-input"
              type={f.type}
              placeholder={f.ph}
              autoComplete={f.auto}
              value={form[f.key]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
            />
            {errors[f.key] && <div className="form-error" role="alert">{errors[f.key]}</div>}
          </div>
        ))}
        <button type="button" className="btn btn-primary w-full" onClick={handleSubmit} style={{ justifyContent: "center", height: 40 }}>
          Create account
        </button>
        <div className="auth-divider" aria-hidden="true">or</div>
        <div className="text-sm" style={{ textAlign: "center", color: "var(--text2)" }}>
          Already have an account?{" "}
          <button type="button" className="auth-link" onClick={() => onNavigate("login")}>Sign in</button>
        </div>
      </div>
    </div>
  );
}

function ForgotPage({ onNavigate }) {
  const [email, setEmail] = useState("");
  const [sent, setSent]   = useState(false);

  return (
    <div className="auth-page">
      <div className="auth-card" role="main">
        <div className="auth-logo">
          <div className="brand-icon" aria-hidden="true">✦</div>
          <div className="brand-name">Quantix UI</div>
        </div>
        <h1 className="auth-title">Reset password</h1>
        <p className="auth-sub">We'll send you a reset link</p>
        {sent ? (
          <div className="auth-success" role="status">
            Reset link sent to <strong>{email}</strong>. Check your inbox.
          </div>
        ) : (
          <>
            <div className="form-group">
              <label className="form-label" htmlFor="forgot-email">Email address</label>
              <input
                id="forgot-email"
                name="email"
                className="form-input"
                type="email"
                placeholder="admin@quantix.io"
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                onKeyDown={e => e.key === "Enter" && email && setSent(true)}
              />
            </div>
            <button
              type="button"
              className="btn btn-primary w-full"
              onClick={() => email && setSent(true)}
              style={{ justifyContent: "center", height: 40 }}
              disabled={!email}
            >
              Send reset link
            </button>
          </>
        )}
        <div className="text-sm" style={{ marginTop: 14, textAlign: "center", color: "var(--text2)" }}>
          <button type="button" className="auth-link" onClick={() => onNavigate("login")}>← Back to login</button>
        </div>
      </div>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
const navItems = [
  { section: "Overview" },
  { id: "dashboard", label: "AI Dashboard", icon: "🤖" },
  { id: "analytics", label: "Analytics",    icon: "📊" },
  { section: "Management" },
  { id: "crm",      label: "CRM",      icon: "👥" },
  { id: "finance",  label: "Finance",  icon: "💰" },
  { id: "projects", label: "Projects", icon: "🗂️" },
  { section: "Tools" },
  { id: "kanban",   label: "Kanban",   icon: "📌" },
  { id: "calendar", label: "Calendar", icon: "📅" },
  { id: "chat",     label: "AI Chat",  icon: "💬", badge: "New" },
  { id: "email",    label: "Email",    icon: "✉️" },
  { section: "Account" },
  { id: "settings", label: "Settings", icon: "⚙️" },
];

function Sidebar({ active, onNav, collapsed, onToggle, mobileOpen }) {
  const unreadEmails = 2;
  return (
    <nav
      className={`sidebar${collapsed ? " collapsed" : ""}${mobileOpen ? " mobile-open" : ""}`}
      aria-label="Main navigation"
    >
      <div className="sidebar-brand">
        <div className="brand-icon" aria-hidden="true">✦</div>
        {!collapsed && (
          <>
            <div>
              <div className="brand-name">Quantix UI</div>
            </div>
            <div className="brand-tag" style={{ marginLeft: "auto" }}>PRO</div>
          </>
        )}
      </div>
      <div className="nav-section" role="list">
        {navItems.map((item, i) => {
          if (item.section) {
            return collapsed ? null : (
              <div key={`section-${i}`} className="nav-label" aria-hidden="true">{item.section}</div>
            );
          }
          return (
            <button
              key={item.id}
              type="button"
              role="listitem"
              className={`nav-item${active === item.id ? " active" : ""}`}
              onClick={() => onNav(item.id)}
              aria-current={active === item.id ? "page" : undefined}
              aria-label={collapsed ? item.label : undefined}
              title={collapsed ? item.label : undefined}
            >
              <span className="nav-icon" aria-hidden="true">{item.icon}</span>
              {!collapsed && <span style={{ flex: 1 }}>{item.label}</span>}
              {!collapsed && item.id === "email" && unreadEmails > 0 && (
                <span className="nav-badge" aria-label={`${unreadEmails} unread`}>{unreadEmails}</span>
              )}
              {!collapsed && item.badge && (
                <span className="nav-badge">{item.badge}</span>
              )}
            </button>
          );
        })}
      </div>
      {!collapsed && (
        <div style={{ padding: "12px", borderTop: "1px solid var(--border)" }}>
          <div style={{ background: "var(--glow)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: "var(--radius)", padding: "10px 12px" }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "var(--accent)", marginBottom: 4 }}>✨ Pro Plan</div>
            <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 8 }}>82% of storage used</div>
            <div className="progress-bar" role="progressbar" aria-valuenow={82} aria-valuemin={0} aria-valuemax={100} aria-label="Storage used">
              <div className="progress-fill" style={{ width: "82%" }}></div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

// ─── HEADER ───────────────────────────────────────────────────────────────────
function Header({ onMenuToggle, page, darkMode, toggleDark, onLogout, onNav, notifications, setNotifications }) {
  const [showNotif,   setShowNotif]   = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const notifRef   = useRef(null);
  const profileRef = useRef(null);

  const unread = notifications.filter(n => !n.read).length;

  const markAllRead = () => setNotifications(p => p.map(n => ({ ...n, read: true })));
  const markRead    = (id) => setNotifications(p => p.map(n => n.id === id ? { ...n, read: true } : n));

  useEffect(() => {
    const handler = (e) => {
      if (notifRef.current   && !notifRef.current.contains(e.target))   setShowNotif(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setShowProfile(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const pageTitles = {
    dashboard: "AI Dashboard", analytics: "Analytics", crm: "CRM",
    finance: "Finance", projects: "Projects", kanban: "Kanban",
    calendar: "Calendar", chat: "AI Chat", email: "Email", settings: "Settings",
  };

  return (
    <header className="site-header">
      <button
        type="button"
        className="h-btn"
        onClick={onMenuToggle}
        aria-label="Toggle sidebar"
        aria-expanded={undefined}
      >
        ☰
      </button>
      <div style={{ fontWeight: 700, fontSize: 15, marginRight: 8 }} aria-live="polite">
        {pageTitles[page] || "Dashboard"}
      </div>
      <div className="h-spacer" />
      <div className="h-search">
        <label htmlFor="global-search" className="h-search-icon" aria-hidden="true">🔍</label>
        <input
          id="global-search"
          name="search"
          type="search"
          placeholder="Search anything…"
          aria-label="Search the dashboard"
          autoComplete="off"
        />
      </div>
      <button
        type="button"
        className="h-btn"
        onClick={toggleDark}
        aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
        aria-pressed={darkMode}
      >
        {darkMode ? <Sun size={16} strokeWidth={2} /> : <Moon size={16} strokeWidth={2} />}
      </button>

      {/* Notification dropdown */}
      <div className="relative" ref={notifRef}>
        <button
          type="button"
          className="h-btn"
          onClick={() => { setShowNotif(p => !p); setShowProfile(false); }}
          aria-label={`Notifications${unread > 0 ? ` — ${unread} unread` : ""}`}
          aria-expanded={showNotif}
          aria-haspopup="true"
        >
          <Bell size={16} strokeWidth={2} />
          {unread > 0 && (
            <span className="badge-count" aria-hidden="true">{unread}</span>
          )}
        </button>
        {showNotif && (
          <div
            className="dropdown"
            style={{ width: 320 }}
            role="dialog"
            aria-label="Notifications panel"
          >
            <div className="dropdown-header" style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div className="dropdown-name">Notifications</div>
                <div className="dropdown-email">{unread} unread</div>
              </div>
              {unread > 0 && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={markAllRead}>
                  Mark all read
                </button>
              )}
            </div>
            {notifications.map(n => (
              <div
                key={n.id}
                className={`notif-item${n.read ? "" : " unread"}`}
                onClick={() => markRead(n.id)}
                role="button"
                tabIndex={0}
                onKeyDown={e => e.key === "Enter" && markRead(n.id)}
                aria-label={`${n.read ? "" : "Unread: "}${n.text} — ${n.time}`}
              >
                <span className="notif-icon" aria-hidden="true">{n.icon}</span>
                <div>
                  <div className="notif-text">{n.text}</div>
                  <div className="notif-time">{n.time}</div>
                </div>
                {!n.read && (
                  <div style={{ width: 7, height: 7, background: "var(--accent)", borderRadius: "50%", flexShrink: 0, marginLeft: "auto", marginTop: 4 }} aria-hidden="true" />
                )}
              </div>
            ))}
            <button type="button" className="notif-footer" onClick={() => setShowNotif(false)}>
              View all notifications
            </button>
          </div>
        )}
      </div>

      {/* Profile dropdown */}
      <div className="relative" ref={profileRef}>
        <button
          type="button"
          className="avatar"
          onClick={() => { setShowProfile(p => !p); setShowNotif(false); }}
          aria-label="Profile menu"
          aria-expanded={showProfile}
          aria-haspopup="true"
        >
          AM
        </button>
        {showProfile && (
          <div className="dropdown" role="dialog" aria-label="Profile menu">
            <div className="dropdown-header">
              <div className="dropdown-name">Alex Morgan</div>
              <div className="dropdown-email">admin@quantix.io</div>
            </div>
            <button type="button" className="dropdown-item" onClick={() => { onNav("settings"); setShowProfile(false); }}>
              ⚙️ Profile Settings
            </button>
            <button type="button" className="dropdown-item" onClick={() => { onNav("billing"); setShowProfile(false); }}>
              💳 Billing
            </button>
            <hr className="dropdown-divider" />
            <button type="button" className="dropdown-item danger" onClick={onLogout}>
              🚪 Sign out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

// ─── AI DASHBOARD ─────────────────────────────────────────────────────────────
function DashboardPage() {
  const [showNewReport,   setShowNewReport]   = useState(false);
  const [showAllActivity, setShowAllActivity] = useState(false);
  const [reportForm, setReportForm] = useState({ name: "", type: "Revenue", range: "Last 30 days", format: "PDF" });
  const [reportSaved,  setReportSaved]  = useState(false);

  const kpis = [
    { label: "Total Revenue",    value: "$284K",  change: "+18.2%", up: true,  icon: "💰", cls: "kpi-accent" },
    { label: "Active Users",     value: "42,891", change: "+11.7%", up: true,  icon: "👥", cls: "kpi-green" },
    { label: "AI Queries / Day", value: "18,240", change: "+34.1%", up: true,  icon: "🤖", cls: "kpi-cyan" },
    { label: "Churn Rate",       value: "2.8%",   change: "-1.4%",  up: true,  icon: "📉", cls: "kpi-orange" },
  ];

  const allActivity = [
    { id: "a1",  action: "New enterprise lead",    user: "Sarah Chen",   time: "2 min ago",  status: "Lead" },
    { id: "a2",  action: "Payment received",        user: "Meridian Labs", time: "18 min ago", status: "Payment" },
    { id: "a3",  action: "AI model deployed",       user: "System",        time: "1h ago",     status: "Deploy" },
    { id: "a4",  action: "Support ticket closed",   user: "Marcus R.",     time: "2h ago",     status: "Support" },
    { id: "a5",  action: "New user registered",     user: "Priya Nair",    time: "3h ago",     status: "User" },
    { id: "a6",  action: "Invoice paid",            user: "Cobalt Tech",   time: "4h ago",     status: "Payment" },
    { id: "a7",  action: "API key generated",       user: "Dev Team",      time: "5h ago",     status: "Deploy" },
    { id: "a8",  action: "Report exported",         user: "Alex Morgan",   time: "6h ago",     status: "Report" },
    { id: "a9",  action: "New lead qualified",      user: "Tom Nakamura",  time: "8h ago",     status: "Lead" },
    { id: "a10", action: "Subscription upgraded",   user: "Neon Digital",  time: "10h ago",    status: "Payment" },
    { id: "a11", action: "Onboarding completed",    user: "Elena Vasquez", time: "12h ago",    status: "User" },
    { id: "a12", action: "Webhook triggered",        user: "System",        time: "14h ago",    status: "Deploy" },
  ];

  const activity = showAllActivity ? allActivity : allActivity.slice(0, 5);

  const submitReport = () => {
    if (!reportForm.name) return;
    setReportSaved(true);
    setTimeout(() => {
      setReportSaved(false);
      setShowNewReport(false);
      setReportForm({ name: "", type: "Revenue", range: "Last 30 days", format: "PDF" });
    }, 1400);
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">AI Dashboard</h2>
          <p className="page-sub">Welcome back, Alex 👋 Here's what's happening today.</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setShowNewReport(true)}>
          + New Report
        </button>
      </div>

      {/* KPI Grid */}
      <div className="grid-4 section-gap">
        {kpis.map(k => (
          <div key={k.label} className={`kpi ${k.cls}`}>
            <div className="kpi-icon" aria-hidden="true">{k.icon}</div>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className={`kpi-change ${k.up ? "up" : "down"}`}>
              <span aria-hidden="true">{k.up ? "▲" : "▼"}</span> {k.change} vs last month
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid-2 section-gap">
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="card-title">AI Usage Trend</div>
            <span className="badge badge-qualified">Live</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={aiUsageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="week" tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={fmtNum} />
              <Tooltip contentStyle={{ background: "var(--bg2)", border: "1px solid var(--border2)", borderRadius: 8, fontSize: 12 }} />
              <Line type="monotone" dataKey="queries" stroke="var(--accent)"  strokeWidth={2} dot={false} name="Queries" />
              <Line type="monotone" dataKey="tokens"  stroke="var(--accent2)" strokeWidth={2} dot={false} name="Tokens" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div className="card-title mb-3">Plan Distribution</div>
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={3}>
                  {pieData.map(entry => <Cell key={entry.name} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div style={{ flex: 1 }}>
              {pieData.map(d => (
                <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: d.color, flexShrink: 0 }} aria-hidden="true" />
                  <span style={{ fontSize: 12, flex: 1 }}>{d.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 700 }}>{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <div className="card-title">Recent Activity</div>
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            onClick={() => setShowAllActivity(v => !v)}
            aria-expanded={showAllActivity}
          >
            {showAllActivity ? "Show less ↑" : "View all ↓"}
          </button>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th scope="col">Action</th>
                <th scope="col">User / Source</th>
                <th scope="col">Time</th>
                <th scope="col">Type</th>
              </tr>
            </thead>
            <tbody>
              {activity.map(a => (
                <tr key={a.id}>
                  <td style={{ fontWeight: 500 }}>{a.action}</td>
                  <td className="text-muted">{a.user}</td>
                  <td className="text-dim text-sm">{a.time}</td>
                  <td><span className="badge badge-medium">{a.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Report Modal */}
      {showNewReport && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && setShowNewReport(false)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="report-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="report-modal-title" className="modal-title">📊 Create New Report</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={() => setShowNewReport(false)}>✕</button>
            </div>
            <div className="modal-body">
              {reportSaved ? (
                <div style={{ textAlign: "center", padding: "24px 0" }} role="status">
                  <div style={{ fontSize: 36, marginBottom: 10 }} aria-hidden="true">✅</div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>Report created!</div>
                  <div style={{ color: "var(--text3)", fontSize: 13, marginTop: 4 }}>"{reportForm.name}" has been queued for generation.</div>
                </div>
              ) : (
                <>
                  <div className="form-group">
                    <label className="form-label" htmlFor="report-name">Report Name <span aria-hidden="true">*</span></label>
                    <input
                      id="report-name"
                      name="reportName"
                      className="form-input"
                      type="text"
                      placeholder="e.g. Q3 Revenue Summary"
                      value={reportForm.name}
                      onChange={e => setReportForm(p => ({ ...p, name: e.target.value }))}
                      aria-required="true"
                    />
                    {!reportForm.name && (
                      <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 3 }}>Required</div>
                    )}
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="report-type">Report Type</label>
                    <select
                      id="report-type"
                      name="reportType"
                      className="form-input form-select"
                      value={reportForm.type}
                      onChange={e => setReportForm(p => ({ ...p, type: e.target.value }))}
                    >
                      {["Revenue", "User Growth", "AI Usage", "Traffic", "Churn Analysis", "Invoice Summary"].map(t => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="report-range">Date Range</label>
                    <select
                      id="report-range"
                      name="reportRange"
                      className="form-input form-select"
                      value={reportForm.range}
                      onChange={e => setReportForm(p => ({ ...p, range: e.target.value }))}
                    >
                      {["Last 7 days", "Last 30 days", "Last 90 days", "This year", "Custom"].map(r => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <p className="form-label" id="format-label">Export Format</p>
                    <div className="flex gap-2" role="group" aria-labelledby="format-label">
                      {["PDF", "CSV", "Excel"].map(f => (
                        <div
                          key={f}
                          role="radio"
                          aria-checked={reportForm.format === f}
                          tabIndex={0}
                          onClick={() => setReportForm(p => ({ ...p, format: f }))}
                          onKeyDown={e => (e.key === "Enter" || e.key === " ") && setReportForm(p => ({ ...p, format: f }))}
                          style={{
                            flex: 1, padding: "8px", textAlign: "center", borderRadius: 8,
                            border: `2px solid ${reportForm.format === f ? "var(--accent)" : "var(--border)"}`,
                            cursor: "pointer", fontSize: 13, fontWeight: 600,
                            background: reportForm.format === f ? "var(--glow)" : "var(--bg3)",
                            color: reportForm.format === f ? "var(--accent)" : "var(--text2)",
                          }}
                        >
                          {f === "PDF" ? "📄" : f === "CSV" ? "📋" : "📊"} {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
            {!reportSaved && (
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowNewReport(false)}>Cancel</button>
                <button type="button" className="btn btn-primary" onClick={submitReport} disabled={!reportForm.name}>
                  Generate Report
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── ANALYTICS ────────────────────────────────────────────────────────────────
function AnalyticsPage() {
  const [period, setPeriod]             = useState("7d");
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef(null);
  const dataMap   = { "7d": revenueData.slice(-3), "30d": revenueData.slice(-5), "90d": revenueData };

  useEffect(() => {
    const handler = (e) => {
      if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const exportCSV = (type) => {
    let rows, filename;
    if (type === "revenue") {
      rows = [["Month","Revenue","Expenses","Profit"], ...revenueData.map(r => [r.month, r.revenue, r.expenses, r.revenue - r.expenses])];
      filename = "analytics-revenue.csv";
    } else {
      rows = [["Day","Organic","Paid","Direct"], ...trafficData.map(r => [r.day, r.organic, r.paid, r.direct])];
      filename = "analytics-traffic.csv";
    }
    downloadCSV(rows.map(r => r.join(",")).join("\n"), filename);
    setShowExportMenu(false);
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">Analytics</h2>
          <p className="page-sub">Performance insights and traffic overview</p>
        </div>
        <div className="relative" ref={exportRef}>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => setShowExportMenu(v => !v)}
            aria-expanded={showExportMenu}
            aria-haspopup="true"
          >
            ⬇️ Export ▾
          </button>
          {showExportMenu && (
            <div className="dropdown" style={{ right: 0, minWidth: 180 }} role="menu">
              <button type="button" className="dropdown-item" role="menuitem" onClick={() => exportCSV("revenue")}>
                📊 Revenue Data (CSV)
              </button>
              <button type="button" className="dropdown-item" role="menuitem" onClick={() => exportCSV("traffic")}>
                📈 Traffic Data (CSV)
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="grid-4 section-gap">
        {[
          { label: "Total Revenue", value: "$1.24M", change: "+22%",  up: true },
          { label: "Avg Session",   value: "4m 32s", change: "+8%",   up: true },
          { label: "Bounce Rate",   value: "38.2%",  change: "-4%",   up: true },
          { label: "Conversion",    value: "3.7%",   change: "+0.9%", up: true },
        ].map(k => (
          <div key={k.label} className="kpi kpi-accent">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value" style={{ fontSize: 22 }}>{k.value}</div>
            <div className={`kpi-change ${k.up ? "up" : "down"}`}>
              <span aria-hidden="true">{k.up ? "▲" : "▼"}</span> {k.change}
            </div>
          </div>
        ))}
      </div>

      <div className="card section-gap">
        <div className="flex items-center justify-between mb-3">
          <div className="card-title">Revenue Overview</div>
          <div className="toggle-group" role="group" aria-label="Time period">
            {["7d", "30d", "90d"].map(p => (
              <button
                key={p}
                type="button"
                className={`toggle-btn${period === p ? " active" : ""}`}
                onClick={() => setPeriod(p)}
                aria-pressed={period === p}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={dataMap[period]}>
            <defs>
              <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="var(--accent)"  stopOpacity={0.3} />
                <stop offset="95%" stopColor="var(--accent)"  stopOpacity={0} />
              </linearGradient>
              <linearGradient id="exp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="var(--accent2)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="var(--accent2)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="month" tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}K`} />
            <Tooltip contentStyle={{ background: "var(--bg2)", border: "1px solid var(--border2)", borderRadius: 8, fontSize: 12 }} formatter={v => `$${v.toLocaleString()}`} />
            <Area type="monotone" dataKey="revenue"  stroke="var(--accent)"  fill="url(#rev)" strokeWidth={2} name="Revenue" />
            <Area type="monotone" dataKey="expenses" stroke="var(--accent2)" fill="url(#exp)" strokeWidth={2} name="Expenses" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="card">
        <div className="card-title mb-3">Traffic Sources (Weekly)</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={trafficData} barSize={10} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="day"  tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={fmtNum} />
            <Tooltip contentStyle={{ background: "var(--bg2)", border: "1px solid var(--border2)", borderRadius: 8, fontSize: 12 }} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="organic" fill="var(--accent)"  radius={[4,4,0,0]} name="Organic" />
            <Bar dataKey="paid"    fill="var(--accent2)" radius={[4,4,0,0]} name="Paid" />
            <Bar dataKey="direct"  fill="var(--accent3)" radius={[4,4,0,0]} name="Direct" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ─── CRM ──────────────────────────────────────────────────────────────────────
function CRMPage({ toast }) {
  const [leads, setLeads]   = useState(initialLeads);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [sort, setSort]     = useState({ key: "date", dir: -1 });
  const [page, setPage]     = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm]     = useState({ name: "", company: "", email: "", status: "Hot", value: "" });
  const [errors, setErrors] = useState({});
  const PER_PAGE = 4;

  const validate = () => {
    const e = {};
    if (!form.name) e.name = "Required";
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = "Valid email required";
    if (!form.company) e.company = "Required";
    if (!form.value || isNaN(+form.value)) e.value = "Enter a number";
    return e;
  };

  const addLead = () => {
    const e = validate(); setErrors(e);
    if (Object.keys(e).length) return;
    setLeads(p => [...p, { id: Date.now(), ...form, value: +form.value, date: new Date().toISOString().slice(0, 10) }]);
    setShowModal(false);
    setForm({ name: "", company: "", email: "", status: "Hot", value: "" });
    toast("Lead added successfully!");
  };

  const closeModal = () => { setShowModal(false); setErrors({}); setForm({ name: "", company: "", email: "", status: "Hot", value: "" }); };

  const exportCSV = () => {
    const rows = [
      ["Name","Company","Email","Status","Value","Date"],
      ...leads.map(l => [l.name, l.company, l.email, l.status, l.value, l.date]),
    ];
    downloadCSV(rows.map(r => r.join(",")).join("\n"), "leads.csv");
    toast("CSV exported!");
  };

  const filtered = leads
    .filter(l => (filter === "All" || l.status === filter) && (l.name + l.company + l.email).toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => sort.dir * (String(a[sort.key]) > String(b[sort.key]) ? 1 : -1));

  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const pages = Math.ceil(filtered.length / PER_PAGE);
  const setS  = k => setSort(p => ({ key: k, dir: p.key === k ? -p.dir : 1 }));

  const leadFormFields = [
    { key: "name",    label: "Full Name",   type: "text",   ph: "Alex Morgan",  auto: "name" },
    { key: "company", label: "Company",     type: "text",   ph: "Acme Corp",    auto: "organization" },
    { key: "email",   label: "Email",       type: "email",  ph: "alex@acme.com",auto: "email" },
    { key: "value",   label: "Deal Value",  type: "number", ph: "25000",        auto: "off" },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">CRM</h2>
          <p className="page-sub">{leads.length} total leads</p>
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn btn-secondary" onClick={exportCSV}>⬇️ Export CSV</button>
          <button type="button" className="btn btn-primary"   onClick={() => setShowModal(true)}>+ Add Lead</button>
        </div>
      </div>

      <div className="card">
        <div className="flex gap-3 mb-3" style={{ flexWrap: "wrap", alignItems: "center" }}>
          <div>
            <label htmlFor="crm-search" className="hidden">Search leads</label>
            <input
              id="crm-search"
              name="search"
              type="search"
              className="form-input"
              style={{ maxWidth: 240 }}
              placeholder="🔍 Search leads…"
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
            />
          </div>
          <div className="toggle-group" role="group" aria-label="Filter by status">
            {["All", "Hot", "Warm", "Cold", "Qualified"].map(f => (
              <button
                key={f}
                type="button"
                className={`toggle-btn${filter === f ? " active" : ""}`}
                onClick={() => { setFilter(f); setPage(1); }}
                aria-pressed={filter === f}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {[["name","Name"],["company","Company"],["status","Status"],["value","Value"],["date","Date"]].map(([k, l]) => (
                  <th
                    key={k}
                    scope="col"
                    className="clickable"
                    onClick={() => setS(k)}
                    aria-sort={sort.key === k ? (sort.dir === 1 ? "ascending" : "descending") : "none"}
                  >
                    {l} {sort.key === k ? (sort.dir === 1 ? "↑" : "↓") : ""}
                  </th>
                ))}
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paged.map(l => (
                <tr key={l.id}>
                  <td>
                    <div style={{ fontWeight: 600 }}>{l.name}</div>
                    <div style={{ fontSize: 11, color: "var(--text3)" }}>{l.email}</div>
                  </td>
                  <td>{l.company}</td>
                  <td><span className={`badge badge-${l.status.toLowerCase()}`}>{l.status}</span></td>
                  <td style={{ fontWeight: 600 }}>{fmt(l.value)}</td>
                  <td className="text-sm text-muted">{l.date}</td>
                  <td>
                    <button
                      type="button"
                      className="btn btn-danger btn-xs"
                      aria-label={`Delete lead ${l.name}`}
                      onClick={() => { setLeads(p => p.filter(x => x.id !== l.id)); toast("Lead deleted"); }}
                    >
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {pages > 1 && (
          <div className="flex items-center justify-between mt-3" style={{ paddingTop: 12, borderTop: "1px solid var(--border)" }}>
            <span className="text-sm text-muted">Page {page} of {pages}</span>
            <div className="flex gap-2">
              <button type="button" className="btn btn-secondary btn-sm" disabled={page === 1}     onClick={() => setPage(p => p - 1)}>← Prev</button>
              <button type="button" className="btn btn-secondary btn-sm" disabled={page === pages} onClick={() => setPage(p => p + 1)}>Next →</button>
            </div>
          </div>
        )}
      </div>

      {/* Add Lead Modal */}
      {showModal && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && closeModal()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="lead-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="lead-modal-title" className="modal-title">Add New Lead</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={closeModal}>✕</button>
            </div>
            <div className="modal-body">
              {leadFormFields.map(({ key: fk, label, type, ph, auto }) => (
                <div className="form-group" key={fk}>
                  <label className="form-label" htmlFor={`lead-${fk}`}>{label}</label>
                  <input
                    id={`lead-${fk}`}
                    name={fk}
                    className="form-input"
                    type={type}
                    placeholder={ph}
                    autoComplete={auto}
                    value={form[fk]}
                    onChange={e => setForm(p => ({ ...p, [fk]: e.target.value }))}
                    aria-required="true"
                  />
                  {errors[fk] && <div className="form-error" role="alert">{errors[fk]}</div>}
                </div>
              ))}
              <div className="form-group">
                <label className="form-label" htmlFor="lead-status">Status</label>
                <select
                  id="lead-status"
                  name="status"
                  className="form-input form-select"
                  value={form.status}
                  onChange={e => setForm(p => ({ ...p, status: e.target.value }))}
                >
                  {["Hot", "Warm", "Cold", "Qualified"].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
              <button type="button" className="btn btn-primary" onClick={addLead}>Add Lead</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── FINANCE ──────────────────────────────────────────────────────────────────
function FinancePage({ toast }) {
  const [invoices, setInvoices] = useState([
    { id: "INV-001", client: "Vertex Corp",   amount: 12400, status: "Paid",    date: "Jul 15" },
    { id: "INV-002", client: "Meridian Labs", amount: 8750,  status: "Pending", date: "Jul 18" },
    { id: "INV-003", client: "Solaris AI",    amount: 5200,  status: "Paid",    date: "Jul 20" },
    { id: "INV-004", client: "Cobalt Tech",   amount: 19800, status: "Overdue", date: "Jul 05" },
    { id: "INV-005", client: "Neon Digital",  amount: 6300,  status: "Draft",   date: "Jul 22" },
  ]);
  const [page, setPage]       = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [invForm, setInvForm] = useState({ client: "", amount: "", status: "Draft", date: "" });
  const [invErrors, setInvErrors] = useState({});
  const PER = 3;

  const validateInv = () => {
    const e = {};
    if (!invForm.client) e.client = "Client name required";
    if (!invForm.amount || isNaN(+invForm.amount) || +invForm.amount <= 0) e.amount = "Enter a valid amount";
    return e;
  };

  const addInvoice = () => {
    const e = validateInv(); setInvErrors(e);
    if (Object.keys(e).length) return;
    const nextNum = String(invoices.length + 1).padStart(3, "0");
    const today   = new Date();
    const dateStr = invForm.date
      ? new Date(invForm.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })
      : today.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    setInvoices(p => [...p, { id: `INV-${nextNum}`, client: invForm.client, amount: +invForm.amount, status: invForm.status, date: dateStr }]);
    setShowModal(false);
    setInvForm({ client: "", amount: "", status: "Draft", date: "" });
    setInvErrors({});
    toast && toast("Invoice created!");
  };

  const closeModal = () => { setShowModal(false); setInvErrors({}); setInvForm({ client: "", amount: "", status: "Draft", date: "" }); };

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">Finance</h2>
          <p className="page-sub">Revenue &amp; invoice management</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Invoice</button>
      </div>

      <div className="grid-4 section-gap">
        {[
          { label: "MRR",         value: "$68,400",  change: "+12%", up: true },
          { label: "ARR",         value: "$820,800", change: "+18%", up: true },
          { label: "Outstanding", value: "$28,550",  change: "+5%",  up: false },
          { label: "Expenses",    value: "$41,200",  change: "-3%",  up: true },
        ].map(k => (
          <div key={k.label} className="kpi kpi-accent">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value" style={{ fontSize: 22 }}>{k.value}</div>
            <div className={`kpi-change ${k.up ? "up" : "down"}`}>
              <span aria-hidden="true">{k.up ? "▲" : "▼"}</span> {k.change}
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2 section-gap">
        <div className="card">
          <div className="card-title mb-3">Monthly Revenue vs Expenses</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={revenueData} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "var(--text3)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v / 1000}K`} />
              <Tooltip contentStyle={{ background: "var(--bg2)", border: "1px solid var(--border2)", borderRadius: 8, fontSize: 12 }} formatter={v => `$${v.toLocaleString()}`} />
              <Bar dataKey="revenue"  fill="var(--accent)" radius={[4,4,0,0]} name="Revenue" />
              <Bar dataKey="expenses" fill="var(--bg4)"    radius={[4,4,0,0]} name="Expenses" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div className="card-title mb-3">Invoice Status</div>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={[
                  { name: "Paid",    value: 3, color: "var(--green)" },
                  { name: "Pending", value: 1, color: "var(--orange)" },
                  { name: "Overdue", value: 1, color: "var(--red)" },
                ]}
                cx="50%" cy="50%" outerRadius={80} dataKey="value"
              >
                {[{ color: "var(--green)" }, { color: "var(--orange)" }, { color: "var(--red)" }].map((e, i) => (
                  <Cell key={i} fill={e.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "var(--bg2)", border: "1px solid var(--border2)", borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <div className="card-title mb-3">Invoices</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th scope="col">Invoice</th>
                <th scope="col">Client</th>
                <th scope="col">Amount</th>
                <th scope="col">Status</th>
                <th scope="col">Date</th>
                <th scope="col"><span className="hidden">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {invoices.slice((page - 1) * PER, page * PER).map(inv => (
                <tr key={inv.id}>
                  <td style={{ fontFamily: "var(--mono)", fontSize: 12 }}>{inv.id}</td>
                  <td style={{ fontWeight: 500 }}>{inv.client}</td>
                  <td style={{ fontWeight: 700 }}>{fmt(inv.amount)}</td>
                  <td>
                    <span className={`badge ${inv.status === "Paid" ? "badge-qualified" : inv.status === "Pending" ? "badge-warm" : inv.status === "Overdue" ? "badge-hot" : "badge-medium"}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="text-sm text-muted">{inv.date}</td>
                  <td>
                    <button type="button" className="btn btn-ghost btn-xs" aria-label={`View invoice ${inv.id}`}>View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between mt-3" style={{ paddingTop: 12, borderTop: "1px solid var(--border)" }}>
          <span className="text-sm text-muted">
            Showing {Math.min((page - 1) * PER + 1, invoices.length)}–{Math.min(page * PER, invoices.length)} of {invoices.length}
          </span>
          <div className="flex gap-2">
            <button type="button" className="btn btn-secondary btn-sm" disabled={page === 1}                onClick={() => setPage(p => p - 1)}>←</button>
            <button type="button" className="btn btn-secondary btn-sm" disabled={page * PER >= invoices.length} onClick={() => setPage(p => p + 1)}>→</button>
          </div>
        </div>
      </div>

      {/* New Invoice Modal */}
      {showModal && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && closeModal()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="inv-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="inv-modal-title" className="modal-title">🧾 New Invoice</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={closeModal}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label" htmlFor="inv-client">Client Name <span aria-hidden="true">*</span></label>
                <input
                  id="inv-client"
                  name="client"
                  className="form-input"
                  type="text"
                  placeholder="e.g. Acme Corp"
                  autoComplete="organization"
                  value={invForm.client}
                  onChange={e => setInvForm(p => ({ ...p, client: e.target.value }))}
                  aria-required="true"
                />
                {invErrors.client && <div className="form-error" role="alert">{invErrors.client}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="inv-amount">Amount (USD) <span aria-hidden="true">*</span></label>
                <input
                  id="inv-amount"
                  name="amount"
                  className="form-input"
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="e.g. 5000"
                  value={invForm.amount}
                  onChange={e => setInvForm(p => ({ ...p, amount: e.target.value }))}
                  aria-required="true"
                />
                {invErrors.amount && <div className="form-error" role="alert">{invErrors.amount}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="inv-status">Status</label>
                <select
                  id="inv-status"
                  name="status"
                  className="form-input form-select"
                  value={invForm.status}
                  onChange={e => setInvForm(p => ({ ...p, status: e.target.value }))}
                >
                  {["Draft","Pending","Paid","Overdue"].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="inv-date">Invoice Date</label>
                <input
                  id="inv-date"
                  name="invoiceDate"
                  className="form-input"
                  type="date"
                  value={invForm.date}
                  onChange={e => setInvForm(p => ({ ...p, date: e.target.value }))}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
              <button type="button" className="btn btn-primary" onClick={addInvoice}>Create Invoice</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── PROJECTS ─────────────────────────────────────────────────────────────────
function ProjectsPage({ toast }) {
  const [projects, setProjects] = useState(initialProjects);
  const [showModal, setShowModal] = useState(false);
  const [detail, setDetail] = useState(null);
  const [form, setForm]     = useState({ name: "", priority: "Medium", due: "", team: "" });
  const [formError, setFormError] = useState("");

  const addProject = () => {
    if (!form.name.trim()) { setFormError("Project name is required"); return; }
    setFormError("");
    const teamArr = form.team.trim()
      ? form.team.split(",").map(t => t.trim().slice(0, 2).toUpperCase()).filter(Boolean)
      : ["NA"];
    const dueLabel = form.due
      ? new Date(form.due).toLocaleDateString("en-US", { month: "short", day: "numeric" })
      : "TBD";
    setProjects(prev => [...prev, {
      id: Date.now(), name: form.name.trim(), status: "Planning",
      progress: 0, team: teamArr, due: dueLabel, priority: form.priority,
    }]);
    setShowModal(false);
    setForm({ name: "", priority: "Medium", due: "", team: "" });
    toast("Project created!");
  };

  const closeModal = () => { setShowModal(false); setFormError(""); setForm({ name: "", priority: "Medium", due: "", team: "" }); };

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">Projects</h2>
          <p className="page-sub">{projects.length} active projects</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Project</button>
      </div>

      <div className="grid-2">
        {projects.map(p => (
          <article
            key={p.id}
            className="card"
            style={{ cursor: "pointer" }}
            onClick={() => setDetail(p)}
            role="button"
            tabIndex={0}
            onKeyDown={e => (e.key === "Enter" || e.key === " ") && setDetail(p)}
            aria-label={`View project: ${p.name}`}
          >
            <div className="flex items-center justify-between mb-2">
              <div style={{ fontWeight: 700, fontSize: 15 }}>{p.name}</div>
              <span className={`badge badge-${p.priority.toLowerCase()}`}>{p.priority}</span>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <span className={`badge badge-${p.status.toLowerCase().replace(" ", "-")}`}>{p.status}</span>
              <span className="text-sm text-muted">Due: {p.due}</span>
            </div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted">Progress</span>
              <span style={{ fontSize: 13, fontWeight: 700 }}>{p.progress}%</span>
            </div>
            <div className="progress-bar" role="progressbar" aria-valuenow={p.progress} aria-valuemin={0} aria-valuemax={100}>
              <div className="progress-fill" style={{ width: `${p.progress}%` }} />
            </div>
            <div className="flex gap-1 mt-3">
              {p.team.map(m => (
                <div
                  key={m}
                  style={{ width: 26, height: 26, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: "white", border: "2px solid var(--bg2)" }}
                  aria-label={`Team member: ${m}`}
                >
                  {m}
                </div>
              ))}
            </div>
          </article>
        ))}
      </div>

      {/* New Project Modal */}
      {showModal && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && closeModal()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="proj-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="proj-modal-title" className="modal-title">🗂️ New Project</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={closeModal}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label" htmlFor="proj-name">Project Name <span aria-hidden="true">*</span></label>
                <input
                  id="proj-name"
                  name="projectName"
                  className="form-input"
                  type="text"
                  placeholder="e.g. Platform v3 Launch"
                  value={form.name}
                  onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))}
                  onKeyDown={e => e.key === "Enter" && addProject()}
                  aria-required="true"
                  autoFocus
                />
                {formError && <div className="form-error" role="alert">{formError}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="proj-priority">Priority</label>
                <select
                  id="proj-priority"
                  name="priority"
                  className="form-input form-select"
                  value={form.priority}
                  onChange={e => setForm(prev => ({ ...prev, priority: e.target.value }))}
                >
                  {["Low","Medium","High","Critical"].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="proj-due">Due Date</label>
                <input
                  id="proj-due"
                  name="dueDate"
                  className="form-input"
                  type="date"
                  value={form.due}
                  onChange={e => setForm(prev => ({ ...prev, due: e.target.value }))}
                />
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="proj-team">
                  Team Members{" "}
                  <span style={{ color: "var(--text3)", fontWeight: 400 }}>(comma-separated initials, e.g. AK, SR)</span>
                </label>
                <input
                  id="proj-team"
                  name="teamMembers"
                  className="form-input"
                  type="text"
                  placeholder="AK, SR, MJ"
                  value={form.team}
                  onChange={e => setForm(prev => ({ ...prev, team: e.target.value }))}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
              <button type="button" className="btn btn-primary"   onClick={addProject}>Create Project</button>
            </div>
          </div>
        </div>
      )}

      {/* Project Detail Modal */}
      {detail && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && setDetail(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="proj-detail-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="proj-detail-title" className="modal-title">{detail.name}</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={() => setDetail(null)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="grid-2 mb-3">
                <div><div className="text-xs text-dim mb-1">Status</div><span className={`badge badge-${detail.status.toLowerCase().replace(" ","-")}`}>{detail.status}</span></div>
                <div><div className="text-xs text-dim mb-1">Priority</div><span className={`badge badge-${detail.priority.toLowerCase()}`}>{detail.priority}</span></div>
                <div><div className="text-xs text-dim mb-1">Due Date</div><div style={{ fontWeight: 600, fontSize: 13 }}>{detail.due}</div></div>
                <div><div className="text-xs text-dim mb-1">Progress</div><div style={{ fontWeight: 700, fontSize: 18, color: "var(--accent)" }}>{detail.progress}%</div></div>
              </div>
              <div className="progress-bar mb-3" role="progressbar" aria-valuenow={detail.progress} aria-valuemin={0} aria-valuemax={100}>
                <div className="progress-fill" style={{ width: `${detail.progress}%` }} />
              </div>
              <div>
                <div className="text-xs text-dim mb-2">Team Members</div>
                <div className="flex gap-2">
                  {detail.team.map(m => (
                    <div key={m} style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--bg3)", borderRadius: 99, padding: "4px 10px", fontSize: 12, fontWeight: 600 }}>
                      <div style={{ width: 20, height: 20, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: "white" }}>{m}</div>
                      {m}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setDetail(null)}>Close</button>
              <button type="button" className="btn btn-primary">Edit Project</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── KANBAN ───────────────────────────────────────────────────────────────────
function KanbanPage() {
  const [board, setBoard]       = useState(initialKanban);
  const [dragging, setDragging] = useState(null);
  const [dragOver, setDragOver] = useState(null);
  const [showAddTask, setShowAddTask] = useState(false);
  const [taskForm, setTaskForm] = useState({ title: "", tag: "Dev", priority: "Medium", column: "todo" });
  const [taskError, setTaskError] = useState("");

  const cols = [
    { id: "todo",       label: "To Do",      color: "var(--text3)" },
    { id: "inprogress", label: "In Progress", color: "var(--accent)" },
    { id: "review",     label: "Review",      color: "var(--orange)" },
    { id: "done",       label: "Done",        color: "var(--green)" },
  ];

  const onDragStart = (e, card, fromCol) => { setDragging({ card, fromCol }); e.dataTransfer.effectAllowed = "move"; };
  const onDragOver  = (e, colId) => { e.preventDefault(); setDragOver(colId); };
  const onDrop      = (e, toCol) => {
    e.preventDefault();
    if (!dragging || dragging.fromCol === toCol) { setDragging(null); setDragOver(null); return; }
    setBoard(prev => {
      const from = prev[dragging.fromCol].filter(c => c.id !== dragging.card.id);
      const to   = [...prev[toCol], dragging.card];
      return { ...prev, [dragging.fromCol]: from, [toCol]: to };
    });
    setDragging(null); setDragOver(null);
  };

  const addTask = () => {
    if (!taskForm.title.trim()) { setTaskError("Task title is required"); return; }
    setTaskError("");
    const newCard = { id: "t" + uid(), title: taskForm.title.trim(), tag: taskForm.tag, priority: taskForm.priority };
    setBoard(prev => ({ ...prev, [taskForm.column]: [...prev[taskForm.column], newCard] }));
    closeTaskModal();
  };

  const closeTaskModal = () => {
    setShowAddTask(false);
    setTaskError("");
    setTaskForm({ title: "", tag: "Dev", priority: "Medium", column: "todo" });
  };

  const deleteCard = (cardId, colId) => {
    setBoard(prev => ({ ...prev, [colId]: prev[colId].filter(c => c.id !== cardId) }));
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">Kanban Board</h2>
          <p className="page-sub">Drag &amp; drop to manage tasks</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setShowAddTask(true)}>+ Add Task</button>
      </div>

      <div className="kanban-board" role="region" aria-label="Kanban board">
        {cols.map(col => (
          <div
            key={col.id}
            className="kanban-col"
            onDragOver={e => onDragOver(e, col.id)}
            onDrop={e => onDrop(e, col.id)}
            style={{ borderTop: `3px solid ${col.color}`, background: dragOver === col.id ? "var(--glow)" : "var(--bg2)" }}
            aria-label={`${col.label} column`}
            aria-dropeffect="move"
          >
            <div className="kanban-col-header">
              <span>{col.label}</span>
              <span style={{ background: "var(--bg4)", borderRadius: 99, padding: "1px 8px", fontSize: 12 }}>
                {board[col.id].length}
              </span>
            </div>
            <div className="kanban-cards">
              {board[col.id].map(card => (
                <div
                  key={card.id}
                  className={`kanban-card${dragging?.card.id === card.id ? " dragging" : ""}`}
                  draggable
                  onDragStart={e => onDragStart(e, card, col.id)}
                  aria-grabbed={dragging?.card.id === card.id}
                  aria-label={`Task: ${card.title}, priority: ${card.priority}`}
                >
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 8, gap: 6 }}>
                    <div className="kanban-card-title" style={{ margin: 0, flex: 1 }}>{card.title}</div>
                    <button
                      type="button"
                      onClick={e => { e.stopPropagation(); deleteCard(card.id, col.id); }}
                      style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text3)", fontSize: 12, padding: "0 2px", lineHeight: 1, flexShrink: 0, fontFamily: "var(--font)" }}
                      aria-label={`Delete task: ${card.title}`}
                      title="Delete task"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span style={{ fontSize: 11, background: "var(--bg4)", borderRadius: 4, padding: "2px 6px", color: "var(--text2)" }}>
                      {card.tag}
                    </span>
                    <span className={`badge badge-${card.priority.toLowerCase()}`} style={{ fontSize: 10 }}>
                      {card.priority}
                    </span>
                  </div>
                </div>
              ))}
              <div style={{ padding: "6px 0", textAlign: "center" }}>
                <button
                  type="button"
                  className="btn btn-ghost btn-xs w-full"
                  style={{ color: "var(--text3)", fontSize: 11 }}
                  onClick={() => { setTaskForm(prev => ({ ...prev, column: col.id })); setShowAddTask(true); }}
                >
                  + Add card
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Task Modal */}
      {showAddTask && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && closeTaskModal()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="task-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="task-modal-title" className="modal-title">📌 Add New Task</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={closeTaskModal}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label" htmlFor="task-title">Task Title <span aria-hidden="true">*</span></label>
                <input
                  id="task-title"
                  name="taskTitle"
                  className="form-input"
                  type="text"
                  placeholder="e.g. Implement auth flow"
                  value={taskForm.title}
                  onChange={e => setTaskForm(prev => ({ ...prev, title: e.target.value }))}
                  onKeyDown={e => e.key === "Enter" && addTask()}
                  aria-required="true"
                  autoFocus
                />
                {taskError && <div className="form-error" role="alert">{taskError}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="task-column">Column</label>
                <select
                  id="task-column"
                  name="column"
                  className="form-input form-select"
                  value={taskForm.column}
                  onChange={e => setTaskForm(prev => ({ ...prev, column: e.target.value }))}
                >
                  {cols.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                </select>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label" htmlFor="task-tag">Tag</label>
                  <select
                    id="task-tag"
                    name="tag"
                    className="form-input form-select"
                    value={taskForm.tag}
                    onChange={e => setTaskForm(prev => ({ ...prev, tag: e.target.value }))}
                  >
                    {["Dev","Design","Research","Testing","DevOps","Docs","QA","Marketing"].map(t => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="task-priority">Priority</label>
                  <select
                    id="task-priority"
                    name="priority"
                    className="form-input form-select"
                    value={taskForm.priority}
                    onChange={e => setTaskForm(prev => ({ ...prev, priority: e.target.value }))}
                  >
                    {["Low","Medium","High","Critical"].map(v => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeTaskModal}>Cancel</button>
              <button type="button" className="btn btn-primary"   onClick={addTask}>Add Task</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── CALENDAR ─────────────────────────────────────────────────────────────────
function CalendarPage({ toast }) {
  const today = new Date();
  const [cur, setCur]     = useState({ year: today.getFullYear(), month: today.getMonth() });
  const [events, setEvents] = useState([
    { id: 1, date: "2024-07-15", title: "Product sync",   color: "var(--accent)" },
    { id: 2, date: "2024-07-18", title: "Investor call",  color: "var(--green)" },
    { id: 3, date: "2024-07-22", title: "Sprint review",  color: "var(--orange)" },
  ]);
  const [showModal, setShowModal] = useState(false);
  const [selDate, setSelDate]     = useState("");
  const [newTitle, setNewTitle]   = useState("");
  // Inline delete confirmation (replaces window.confirm)
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const daysInMonth = new Date(cur.year, cur.month + 1, 0).getDate();
  const firstDay    = new Date(cur.year, cur.month, 1).getDay();
  const prevDays    = new Date(cur.year, cur.month, 0).getDate();
  const months      = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  const addEvent = () => {
    if (!newTitle || !selDate) return;
    setEvents(p => [...p, { id: Date.now(), date: selDate, title: newTitle, color: "var(--accent)" }]);
    setShowModal(false); setNewTitle(""); toast("Event added!");
  };

  const deleteEvent = (id) => {
    setEvents(p => p.filter(ev => ev.id !== id));
    setConfirmDeleteId(null);
    toast("Event deleted");
  };

  const cells = [];
  for (let i = firstDay - 1; i >= 0; i--) cells.push({ day: prevDays - i, type: "prev" });
  for (let i = 1; i <= daysInMonth; i++) cells.push({ day: i, type: "cur" });
  const rem = 42 - cells.length;
  for (let i = 1; i <= rem; i++) cells.push({ day: i, type: "next" });

  const fmtDate  = d => `${cur.year}-${String(cur.month + 1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
  const todayStr = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">Calendar</h2>
          <p className="page-sub">Schedule and event management</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => { setSelDate(todayStr); setShowModal(true); }}>
          + Add Event
        </button>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div style={{ fontSize: 18, fontWeight: 800 }} aria-live="polite">
            {months[cur.month]} {cur.year}
          </div>
          <div className="flex gap-2" role="group" aria-label="Calendar navigation">
            <button type="button" className="btn btn-secondary btn-sm" aria-label="Previous month"
              onClick={() => setCur(p => p.month === 0 ? { year: p.year - 1, month: 11 } : { ...p, month: p.month - 1 })}>←</button>
            <button type="button" className="btn btn-secondary btn-sm"
              onClick={() => setCur({ year: today.getFullYear(), month: today.getMonth() })}>Today</button>
            <button type="button" className="btn btn-secondary btn-sm" aria-label="Next month"
              onClick={() => setCur(p => p.month === 11 ? { year: p.year + 1, month: 0 } : { ...p, month: p.month + 1 })}>→</button>
          </div>
        </div>

        <div className="cal-grid mb-2" aria-hidden="true">
          {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d => (
            <div key={d} className="cal-day-header">{d}</div>
          ))}
        </div>

        <div className="cal-grid" role="grid" aria-label={`${months[cur.month]} ${cur.year}`}>
          {cells.map((c, i) => {
            const ds       = c.type === "cur" ? fmtDate(c.day) : "";
            const dayEvents = events.filter(e => e.date === ds);
            const isToday   = ds === todayStr;
            return (
              <div
                key={i}
                className={`cal-cell${isToday ? " today" : ""}${c.type !== "cur" ? " other-month" : ""}`}
                onClick={() => { if (c.type === "cur") { setSelDate(ds); setShowModal(true); setConfirmDeleteId(null); } }}
                role="gridcell"
                aria-label={ds || undefined}
                tabIndex={c.type === "cur" ? 0 : -1}
                onKeyDown={e => { if (c.type === "cur" && (e.key === "Enter" || e.key === " ")) { setSelDate(ds); setShowModal(true); } }}
              >
                <div className="cal-date" style={{ color: isToday ? "var(--accent)" : "inherit" }}>{c.day}</div>
                {dayEvents.map(ev => (
                  confirmDeleteId === ev.id ? (
                    <div key={ev.id} className="cal-event-delete">
                      <span>Delete?</span>
                      <div style={{ display: "flex", gap: 4 }}>
                        <button type="button" aria-label="Confirm delete" onClick={e => { e.stopPropagation(); deleteEvent(ev.id); }}>✓</button>
                        <button type="button" aria-label="Cancel delete"  onClick={e => { e.stopPropagation(); setConfirmDeleteId(null); }}>✕</button>
                      </div>
                    </div>
                  ) : (
                    <button
                      key={ev.id}
                      type="button"
                      className="cal-event"
                      style={{ background: ev.color }}
                      onClick={e => { e.stopPropagation(); setConfirmDeleteId(ev.id); }}
                      aria-label={`Event: ${ev.title} — click to delete`}
                      title={ev.title}
                    >
                      {ev.title}
                    </button>
                  )
                ))}
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Event Modal */}
      {showModal && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && setShowModal(false)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="event-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="event-modal-title" className="modal-title">Add Event</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label" htmlFor="event-date">Date</label>
                <input
                  id="event-date"
                  name="eventDate"
                  className="form-input"
                  type="date"
                  value={selDate}
                  onChange={e => setSelDate(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="event-title">Event Title</label>
                <input
                  id="event-title"
                  name="eventTitle"
                  className="form-input"
                  type="text"
                  placeholder="e.g. Team standup"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && addEvent()}
                  autoFocus
                />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="button" className="btn btn-primary"   onClick={addEvent} disabled={!newTitle || !selDate}>Add Event</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── CHAT ─────────────────────────────────────────────────────────────────────
function ChatPage() {
  const [convs, setConvs]     = useState(chatConversations);
  const [activeId, setActiveId] = useState("c1");
  const [input, setInput]     = useState("");
  const [typing, setTyping]   = useState(false);
  const bottomRef = useRef(null);
  const active    = convs.find(c => c.id === activeId);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [active?.messages, typing]);

  const send = () => {
    if (!input.trim()) return;
    const msg = input.trim(); setInput("");
    setConvs(p => p.map(c => c.id === activeId
      ? { ...c, messages: [...c.messages, { role: "user", content: msg }] }
      : c
    ));
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setConvs(p => p.map(c => c.id === activeId
        ? {
            ...c,
            messages: [
              ...c.messages,
              {
                role: "ai",
                content: `I've analyzed your query: **"${msg}"**\n\nBased on the current dashboard data, here are my insights:\n\n1. **Trend analysis** shows positive momentum across key metrics\n2. **Recommendation**: Focus on the highest-impact opportunities\n3. **Action item**: Review the detailed breakdown in Analytics\n\nWould you like me to dive deeper into any specific area?`,
              },
            ],
          }
        : c
      ));
    }, 1200 + Math.random() * 800);
  };

  const newChat = () => {
    const id = "c" + uid();
    setConvs(p => [...p, { id, title: "New conversation", messages: [] }]);
    setActiveId(id);
  };

  return (
    <div>
      <div className="page-header">
        <h2 className="page-title">AI Chat</h2>
      </div>
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="chat-layout">
          {/* Conversation list */}
          <div className="chat-sidebar" role="navigation" aria-label="Conversations">
            <button type="button" className="btn btn-primary w-full mb-3" onClick={newChat} style={{ justifyContent: "center" }}>
              + New Chat
            </button>
            {convs.map(c => (
              <button
                key={c.id}
                type="button"
                className={`conv-item${activeId === c.id ? " active" : ""}`}
                onClick={() => setActiveId(c.id)}
                aria-current={activeId === c.id ? "true" : undefined}
              >
                💬 {c.title}
              </button>
            ))}
          </div>

          {/* Chat main */}
          <div className="chat-main" role="main">
            <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--border)", fontWeight: 700, fontSize: 14 }}>
              {active?.title}
            </div>
            <div className="chat-messages" role="log" aria-live="polite" aria-label="Chat messages">
              {active?.messages.length === 0 && (
                <div style={{ textAlign: "center", color: "var(--text3)", marginTop: 40 }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }} aria-hidden="true">🤖</div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>How can I help you today?</div>
                  <div style={{ fontSize: 12, marginTop: 4 }}>Ask me anything about your data</div>
                </div>
              )}
              {active?.messages.map((m, i) => (
                <div key={i} className={`chat-msg ${m.role}`}>
                  <div
                    className="avatar"
                    style={{
                      background: m.role === "user" ? "var(--accent2)" : "var(--bg4)",
                      fontSize: 12,
                      color: m.role === "user" ? "white" : "var(--accent)",
                    }}
                    aria-hidden="true"
                  >
                    {m.role === "user" ? "AM" : "AI"}
                  </div>
                  {/* Safe: renderMarkdown only replaces **bold** and \n, no external input */}
                  <div
                    className="chat-bubble"
                    dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }}
                  />
                </div>
              ))}
              {typing && (
                <div className="chat-msg ai" aria-label="AI is typing">
                  <div className="avatar" style={{ background: "var(--bg4)", fontSize: 12, color: "var(--accent)" }} aria-hidden="true">AI</div>
                  <div className="chat-bubble">
                    <div className="typing-indicator" aria-label="Typing">
                      <div className="typing-dot" />
                      <div className="typing-dot" />
                      <div className="typing-dot" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={bottomRef} aria-hidden="true" />
            </div>

            <div className="chat-input-area">
              <div className="chat-input-row">
                <label htmlFor="chat-input" className="hidden">Message</label>
                <textarea
                  id="chat-input"
                  name="message"
                  className="chat-input"
                  placeholder="Type a message… (Enter to send, Shift+Enter for new line)"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                  rows={1}
                  aria-label="Chat message input"
                />
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={send}
                  disabled={!input.trim() || typing}
                  aria-label="Send message"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── EMAIL ────────────────────────────────────────────────────────────────────
function EmailPage({ toast }) {
  const [emails, setEmails]       = useState(initialEmails);
  const [folder, setFolder]       = useState("inbox");
  const [selected, setSelected]   = useState(null);
  const [showCompose, setShowCompose] = useState(false);
  const [compose, setCompose]     = useState({ to: "", subject: "", body: "" });
  const [composeErrors, setComposeErrors] = useState({});

  const folders = [
    { id: "inbox",   icon: "📥", label: "Inbox",  count: emails.inbox.filter(e => !e.read).length },
    { id: "starred", icon: "⭐", label: "Starred" },
    { id: "sent",    icon: "📤", label: "Sent" },
    { id: "drafts",  icon: "📝", label: "Drafts", count: emails.drafts.length },
    { id: "trash",   icon: "🗑️", label: "Trash" },
  ];

  const getEmails = () => {
    if (folder === "starred") return [...emails.inbox, ...emails.sent].filter(e => e.starred);
    return emails[folder] || [];
  };

  const markRead    = (id)    => setEmails(p => ({ ...p, inbox: p.inbox.map(e => e.id === id ? { ...e, read: true } : e) }));
  const toggleStar  = (id)    => setEmails(p => {
    const upd = arr => arr.map(e => e.id === id ? { ...e, starred: !e.starred } : e);
    return { ...p, inbox: upd(p.inbox), sent: upd(p.sent) };
  });
  const deleteEmail = (email) => {
    setEmails(p => {
      const remove = arr => arr.filter(e => e.id !== email.id);
      if (folder === "trash") return { ...p, trash: remove(p.trash) };
      return { ...p, [folder]: remove(p[folder]), trash: [...p.trash, { ...email, from: email.from || "Me" }] };
    });
    setSelected(null); toast("Moved to trash");
  };
  const restore     = (email) => {
    setEmails(p => ({ ...p, trash: p.trash.filter(e => e.id !== email.id), inbox: [...p.inbox, email] }));
    toast("Restored to inbox");
  };

  const validateCompose = () => {
    const e = {};
    if (!compose.to || !/\S+@\S+\.\S+/.test(compose.to)) e.to = "Valid email required";
    if (!compose.subject) e.subject = "Subject required";
    return e;
  };

  const sendEmail = () => {
    const e = validateCompose(); setComposeErrors(e);
    if (Object.keys(e).length) return;
    const newEmail = {
      id: `sent_${uid()}`, from: "Me", to: compose.to,
      subject: compose.subject, preview: compose.body.slice(0, 60) + "…",
      date: "Just now", read: true, starred: false,
    };
    setEmails(p => ({ ...p, sent: [newEmail, ...p.sent] }));
    setShowCompose(false); setCompose({ to: "", subject: "", body: "" });
    toast("Email sent!");
  };

  const saveDraft = () => {
    const draft = {
      id: `draft_${uid()}`, from: "Me",
      subject: compose.subject || "(no subject)", preview: compose.body.slice(0, 60),
      date: "Now", read: true, starred: false,
    };
    setEmails(p => ({ ...p, drafts: [draft, ...p.drafts] }));
    setShowCompose(false); setCompose({ to: "", subject: "", body: "" });
    toast("Draft saved");
  };

  const closeCompose = () => { setShowCompose(false); setComposeErrors({}); };
  const curEmails    = getEmails();

  return (
    <div>
      <div className="page-header">
        <h2 className="page-title">Email</h2>
        <button type="button" className="btn btn-primary" onClick={() => setShowCompose(true)}>✏️ Compose</button>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="email-layout">
          {/* Folder list */}
          <nav className="email-sidebar" aria-label="Email folders">
            {folders.map(f => (
              <button
                key={f.id}
                type="button"
                className={`email-folder${folder === f.id ? " active" : ""}`}
                onClick={() => { setFolder(f.id); setSelected(null); }}
                aria-current={folder === f.id ? "true" : undefined}
              >
                <span aria-hidden="true">{f.icon}</span>
                <span style={{ flex: 1 }}>{f.label}</span>
                {f.count > 0 && (
                  <span className="nav-badge" aria-label={`${f.count} unread`}>{f.count}</span>
                )}
              </button>
            ))}
          </nav>

          {/* Email list */}
          <div className="email-list" role="list" aria-label="Emails">
            {curEmails.length === 0 ? (
              <div style={{ padding: 24, textAlign: "center", color: "var(--text3)", fontSize: 13 }}>No emails here</div>
            ) : curEmails.map(e => (
              <div
                key={e.id}
                className={`email-item${selected?.id === e.id ? " active" : ""}${!e.read ? " unread" : ""}`}
                onClick={() => { setSelected(e); if (!e.read) markRead(e.id); }}
                role="listitem button"
                tabIndex={0}
                onKeyDown={ev => (ev.key === "Enter" || ev.key === " ") && (setSelected(e), !e.read && markRead(e.id))}
                aria-label={`${!e.read ? "Unread: " : ""}${e.subject} from ${e.from}`}
                aria-selected={selected?.id === e.id}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="email-from">{e.from}</span>
                  <span className="email-date">{e.date}</span>
                </div>
                <div className="email-subject">{e.subject}</div>
                <div className="email-preview-text">{e.preview}</div>
              </div>
            ))}
          </div>

          {/* Email viewer */}
          <div className="email-view" role="main" aria-label="Email content">
            {selected ? (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div style={{ fontWeight: 800, fontSize: 18 }}>{selected.subject}</div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm"
                      onClick={() => toggleStar(selected.id)}
                      aria-label={selected.starred ? "Unstar email" : "Star email"}
                      aria-pressed={selected.starred}
                    >
                      {selected.starred ? "⭐" : "☆"} Star
                    </button>
                    {folder === "trash" ? (
                      <button type="button" className="btn btn-secondary btn-sm" onClick={() => restore(selected)}>↩ Restore</button>
                    ) : (
                      <button type="button" className="btn btn-danger btn-sm" onClick={() => deleteEmail(selected)}>🗑 Delete</button>
                    )}
                  </div>
                </div>
                <div style={{ fontSize: 13, color: "var(--text3)", marginBottom: 20 }}>
                  <strong>From:</strong> {selected.from} &nbsp; <strong>Date:</strong> {selected.date}
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.7, color: "var(--text2)" }}>{selected.preview}</div>
                <div style={{ marginTop: 20, padding: "12px", background: "var(--bg3)", borderRadius: 8, fontSize: 13, color: "var(--text3)" }}>
                  [Full email body would be displayed here. This is a preview in the demo.]
                </div>
              </>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: "var(--text3)" }}>
                <div style={{ fontSize: 40, marginBottom: 12 }} aria-hidden="true">✉️</div>
                <div>Select an email to read</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Compose Modal */}
      {showCompose && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && closeCompose()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="compose-modal-title"
        >
          <div className="modal modal-lg">
            <div className="modal-header">
              <div id="compose-modal-title" className="modal-title">New Message</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={closeCompose}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label" htmlFor="compose-to">To</label>
                <input
                  id="compose-to"
                  name="to"
                  className="form-input"
                  type="email"
                  placeholder="recipient@example.com"
                  autoComplete="email"
                  value={compose.to}
                  onChange={e => setCompose(p => ({ ...p, to: e.target.value }))}
                  aria-required="true"
                />
                {composeErrors.to && <div className="form-error" role="alert">{composeErrors.to}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="compose-subject">Subject</label>
                <input
                  id="compose-subject"
                  name="subject"
                  className="form-input"
                  type="text"
                  placeholder="Email subject"
                  value={compose.subject}
                  onChange={e => setCompose(p => ({ ...p, subject: e.target.value }))}
                  aria-required="true"
                />
                {composeErrors.subject && <div className="form-error" role="alert">{composeErrors.subject}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="compose-body">Message</label>
                <textarea
                  id="compose-body"
                  name="body"
                  className="form-input"
                  rows={8}
                  placeholder="Write your message…"
                  value={compose.body}
                  onChange={e => setCompose(p => ({ ...p, body: e.target.value }))}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={saveDraft}>Save Draft</button>
              <button type="button" className="btn btn-secondary" onClick={closeCompose}>Cancel</button>
              <button type="button" className="btn btn-primary"   onClick={sendEmail}>Send ✉️</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
function SettingsPage({ initialTab = "profile", toast }) {
  const [tab, setTab]             = useState(initialTab);
  const [profile, setProfile]     = useState({ name: "Alex Morgan", email: "admin@quantix.io", company: "Quantix Labs", role: "Super Admin" });
  const [errors, setErrors]       = useState({});
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [plan, setPlan]           = useState("Pro");
  const [subStatus, setSubStatus] = useState("Active");
  const [showPlanModal, setShowPlanModal]   = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showAddCard, setShowAddCard]       = useState(false);
  const [cards, setCards] = useState([
    { id: 1, last4: "4242", brand: "Visa", expiry: "12/26", name: "Alex Morgan", isDefault: true },
  ]);
  const [newCard, setNewCard]       = useState({ number: "", name: "", expiry: "", cvc: "" });
  const [cardErrors, setCardErrors] = useState({});

  const saveProfile = () => {
    const e = {};
    if (!profile.name) e.name = "Name required";
    if (!profile.email || !/\S+@\S+\.\S+/.test(profile.email)) e.email = "Valid email required";
    setErrors(e);
    if (!Object.keys(e).length) { toast("Profile saved!"); }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast("Please select an image file", "error"); return; }
    if (file.size > 2 * 1024 * 1024) { toast("Image must be under 2MB", "error"); return; }
    const reader = new FileReader();
    reader.onload = ev => { setAvatarPreview(ev.target.result); toast("Photo updated!"); };
    reader.readAsDataURL(file);
  };

  const validateCard = () => {
    const e = {};
    if (!newCard.number || newCard.number.replace(/\s/g, "").length < 16) e.number = "Enter 16-digit card number";
    if (!newCard.name)  e.name   = "Required";
    if (!newCard.expiry || !/^\d{2}\/\d{2}$/.test(newCard.expiry)) e.expiry = "Format: MM/YY";
    if (!newCard.cvc   || newCard.cvc.length < 3)  e.cvc    = "3–4 digits";
    return e;
  };

  const addCard = () => {
    const e = validateCard(); setCardErrors(e);
    if (Object.keys(e).length) return;
    const last4 = newCard.number.replace(/\s/g, "").slice(-4);
    setCards(p => [...p, { id: Date.now(), last4, brand: "Card", expiry: newCard.expiry, name: newCard.name, isDefault: false }]);
    setShowAddCard(false); setNewCard({ number: "", name: "", expiry: "", cvc: "" });
    toast("Payment method added!");
  };

  const closeCardModal = () => { setShowAddCard(false); setCardErrors({}); setNewCard({ number: "", name: "", expiry: "", cvc: "" }); };

  const formatCardNum = (v) => v.replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim().slice(0, 19);

  const plans = [
    { name: "Starter",    price: "$29",  features: ["5 users","10 projects","Basic analytics","Email support"] },
    { name: "Pro",        price: "$79",  features: ["25 users","Unlimited projects","Advanced AI","Priority support"], recommended: true },
    { name: "Enterprise", price: "$199", features: ["Unlimited users","Custom integrations","Dedicated manager","SLA guarantee"] },
  ];

  const profileFields = [
    { key: "name",    label: "Full Name", type: "text",  auto: "name" },
    { key: "email",   label: "Email",     type: "email", auto: "email" },
    { key: "company", label: "Company",   type: "text",  auto: "organization" },
    { key: "role",    label: "Role",      type: "text",  auto: "organization-title" },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h2 className="page-title">Settings</h2>
          <p className="page-sub">Manage your account preferences</p>
        </div>
      </div>

      <div className="settings-nav" role="tablist" aria-label="Settings sections">
        {["profile", "billing"].map(t => (
          <button
            key={t}
            type="button"
            role="tab"
            className={`settings-tab${tab === t ? " active" : ""}`}
            aria-selected={tab === t}
            onClick={() => setTab(t)}
          >
            {t === "profile" ? "👤 Profile" : "💳 Billing"}
          </button>
        ))}
      </div>

      {/* Profile tab */}
      {tab === "profile" && (
        <div className="grid-2" style={{ alignItems: "start" }} role="tabpanel" aria-label="Profile settings">
          <div className="card">
            <div className="card-title mb-3">Profile Photo</div>
            <div className="flex items-center gap-4 mb-4">
              <label htmlFor="avatar-upload" style={{ cursor: "pointer" }} aria-label="Upload profile photo">
                <div className="avatar-upload">
                  {avatarPreview
                    ? <img src={avatarPreview} alt="Profile" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "50%" }} />
                    : <span aria-hidden="true">AM</span>
                  }
                  <div className="avatar-overlay" aria-hidden="true">📷</div>
                </div>
                <input
                  id="avatar-upload"
                  name="avatar"
                  type="file"
                  accept="image/*"
                  style={{ display: "none" }}
                  onChange={handleAvatarChange}
                />
              </label>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>Alex Morgan</div>
                <div style={{ fontSize: 12, color: "var(--text3)" }}>Super Admin</div>
                <div style={{ fontSize: 11, color: "var(--text3)", marginTop: 4 }}>Click photo to change • Max 2MB</div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-title mb-3">Account Information</div>
            {profileFields.map(({ key: fk, label, type, auto }) => (
              <div className="form-group" key={fk}>
                <label className="form-label" htmlFor={`profile-${fk}`}>{label}</label>
                <input
                  id={`profile-${fk}`}
                  name={fk}
                  className="form-input"
                  type={type}
                  autoComplete={auto}
                  value={profile[fk]}
                  onChange={e => setProfile(p => ({ ...p, [fk]: e.target.value }))}
                />
                {errors[fk] && <div className="form-error" role="alert">{errors[fk]}</div>}
              </div>
            ))}
            <button type="button" className="btn btn-primary" onClick={saveProfile}>Save Changes</button>
          </div>
        </div>
      )}

      {/* Billing tab */}
      {tab === "billing" && (
        <div role="tabpanel" aria-label="Billing settings">
          <div className="card section-gap">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="card-title">Current Plan</div>
                <div className="card-sub">
                  You're on the <strong>{plan}</strong> plan — status:{" "}
                  <span style={{ color: subStatus === "Active" ? "var(--green)" : "var(--red)" }}>{subStatus}</span>
                </div>
              </div>
              {subStatus === "Active" && (
                <button type="button" className="btn btn-danger btn-sm" onClick={() => setShowCancelModal(true)}>Cancel Plan</button>
              )}
              {subStatus === "Cancelled" && (
                <button type="button" className="btn btn-primary btn-sm" onClick={() => { setSubStatus("Active"); toast("Subscription reactivated!"); }}>
                  Reactivate
                </button>
              )}
            </div>
            <div className="grid-3">
              {plans.map(p => (
                <div key={p.name} className={`pricing-card${p.recommended ? " recommended" : ""}`}>
                  {p.recommended && (
                    <div style={{ fontSize: 10, fontWeight: 700, color: "var(--accent)", marginBottom: 4, letterSpacing: 1 }}>✦ RECOMMENDED</div>
                  )}
                  <div style={{ fontWeight: 800, fontSize: 16 }}>{p.name}</div>
                  <div className="pricing-price">{p.price}<span className="pricing-period">/mo</span></div>
                  {p.features.map(f => (
                    <div key={f} className="pricing-feature">
                      <span style={{ color: "var(--green)" }} aria-hidden="true">✓</span>{f}
                    </div>
                  ))}
                  <button
                    type="button"
                    className={`btn ${plan === p.name ? "btn-secondary" : "btn-primary"} w-full mt-3`}
                    style={{ justifyContent: "center" }}
                    onClick={() => plan !== p.name && setShowPlanModal(p.name)}
                    disabled={plan === p.name}
                    aria-label={plan === p.name ? `Current plan: ${p.name}` : `Upgrade to ${p.name}`}
                  >
                    {plan === p.name ? "Current Plan" : "Upgrade"}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="card-title">Payment Methods</div>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => setShowAddCard(true)}>+ Add Card</button>
            </div>
            {cards.map(c => (
              <div
                key={c.id}
                style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px", background: "var(--bg3)", borderRadius: 8, marginBottom: 8, border: "1px solid var(--border)" }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 36, height: 24, background: "var(--bg4)", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: "var(--accent)" }} aria-hidden="true">
                    VISA
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>•••• •••• •••• {c.last4}</div>
                    <div style={{ fontSize: 11, color: "var(--text3)" }}>{c.name} · Expires {c.expiry}</div>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  {c.isDefault && <span className="badge badge-qualified">Default</span>}
                  {!c.isDefault && (
                    <button
                      type="button"
                      className="btn btn-ghost btn-xs"
                      onClick={() => { setCards(p => p.map(x => ({ ...x, isDefault: x.id === c.id }))); toast("Default updated"); }}
                    >
                      Set default
                    </button>
                  )}
                  {cards.length > 1 && (
                    <button
                      type="button"
                      className="btn btn-danger btn-xs"
                      aria-label={`Remove card ending in ${c.last4}`}
                      onClick={() => {
                        if (c.isDefault) { toast("Can't delete default card", "error"); return; }
                        setCards(p => p.filter(x => x.id !== c.id)); toast("Card removed");
                      }}
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upgrade Plan Modal */}
      {showPlanModal && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && setShowPlanModal(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="plan-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="plan-modal-title" className="modal-title">Upgrade to {showPlanModal}</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={() => setShowPlanModal(null)}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: "var(--text2)" }}>
                You're about to upgrade from <strong>{plan}</strong> to <strong>{showPlanModal}</strong>. Your billing will be prorated for the current cycle.
              </p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowPlanModal(null)}>Cancel</button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => { setPlan(showPlanModal); setSubStatus("Active"); setShowPlanModal(null); toast(`Upgraded to ${showPlanModal}!`); }}
              >
                Confirm Upgrade
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Subscription Modal */}
      {showCancelModal && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && setShowCancelModal(false)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="cancel-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="cancel-modal-title" className="modal-title" style={{ color: "var(--red)" }}>Cancel Subscription</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={() => setShowCancelModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: "var(--text2)" }}>
                Are you sure you want to cancel? You'll retain access until the end of your billing period and can reactivate at any time.
              </p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowCancelModal(false)}>Keep subscription</button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => { setSubStatus("Cancelled"); setShowCancelModal(false); toast("Subscription cancelled", "info"); }}
              >
                Yes, cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Card Modal */}
      {showAddCard && (
        <div
          className="modal-overlay"
          onClick={e => e.target === e.currentTarget && closeCardModal()}
          role="dialog"
          aria-modal="true"
          aria-labelledby="card-modal-title"
        >
          <div className="modal">
            <div className="modal-header">
              <div id="card-modal-title" className="modal-title">Add Payment Method</div>
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Close dialog" onClick={closeCardModal}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label" htmlFor="card-number">Card Number</label>
                <input
                  id="card-number"
                  name="cardNumber"
                  className="form-input"
                  type="text"
                  inputMode="numeric"
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                  autoComplete="cc-number"
                  value={newCard.number}
                  onChange={e => setNewCard(p => ({ ...p, number: formatCardNum(e.target.value) }))}
                />
                {cardErrors.number && <div className="form-error" role="alert">{cardErrors.number}</div>}
              </div>
              <div className="form-group">
                <label className="form-label" htmlFor="card-holder">Cardholder Name</label>
                <input
                  id="card-holder"
                  name="cardHolder"
                  className="form-input"
                  type="text"
                  placeholder="Alex Morgan"
                  autoComplete="cc-name"
                  value={newCard.name}
                  onChange={e => setNewCard(p => ({ ...p, name: e.target.value }))}
                />
                {cardErrors.name && <div className="form-error" role="alert">{cardErrors.name}</div>}
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label" htmlFor="card-expiry">Expiry</label>
                  <input
                    id="card-expiry"
                    name="expiry"
                    className="form-input"
                    type="text"
                    inputMode="numeric"
                    placeholder="MM/YY"
                    maxLength={5}
                    autoComplete="cc-exp"
                    value={newCard.expiry}
                    onChange={e => setNewCard(p => ({ ...p, expiry: e.target.value.replace(/[^\d/]/g, "") }))}
                  />
                  {cardErrors.expiry && <div className="form-error" role="alert">{cardErrors.expiry}</div>}
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="card-cvc">CVC</label>
                  <input
                    id="card-cvc"
                    name="cvc"
                    className="form-input"
                    type="password"
                    inputMode="numeric"
                    placeholder="123"
                    maxLength={4}
                    autoComplete="cc-csc"
                    value={newCard.cvc}
                    onChange={e => setNewCard(p => ({ ...p, cvc: e.target.value.replace(/\D/g, "") }))}
                  />
                  {cardErrors.cvc && <div className="form-error" role="alert">{cardErrors.cvc}</div>}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeCardModal}>Cancel</button>
              <button type="button" className="btn btn-primary"   onClick={addCard}>Add Card</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [authPage,        setAuthPage]        = useState("login");
  const [authed,          setAuthed]          = useState(false);
  const [page,            setPage]            = useState("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebar,   setMobileSidebar]   = useState(false);
  const [darkMode,        setDarkMode]        = useState(true);
  const [notifications,   setNotifications]   = useState(initialNotifications);
  const { toasts, add: toast } = useToast();

  /** Inject favicon, title and meta description on mount — fixes the 404 error */
  useEffect(() => {
    // Favicon — SVG data URI, no external request
    let link = document.querySelector("link[rel~='icon']");
    if (!link) {
      link = document.createElement("link");
      document.head.appendChild(link);
    }
    link.rel  = "icon";
    link.type = "image/svg+xml";
    link.href = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%236366f1'/%3E%3Ctext y='.9em' font-size='68' x='14' fill='white'%3E✦%3C/text%3E%3C/svg%3E";

    // Page title
    document.title = "Quantix UI — Admin Analytics Hub";

    // Meta description
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "description";
      document.head.appendChild(meta);
    }
    meta.content = "Quantix UI — AI-powered admin analytics dashboard for modern SaaS teams.";

    // Viewport (insurance)
    let viewport = document.querySelector('meta[name="viewport"]');
    if (!viewport) {
      viewport = document.createElement("meta");
      viewport.name = "viewport";
      viewport.content = "width=device-width, initial-scale=1";
      document.head.appendChild(viewport);
    }
  }, []);

  useEffect(() => {
    document.documentElement.className = darkMode ? "" : "light-mode";
  }, [darkMode]);

  const logout   = () => { setAuthed(false); setAuthPage("login"); };
  const login    = () => setAuthed(true);
  const navigate = (p) => { if (p === "billing") { setPage("settings"); } else setPage(p); };

  if (!authed) {
    if (authPage === "register") return <><style>{styles}</style><RegisterPage onNavigate={setAuthPage} /></>;
    if (authPage === "forgot")   return <><style>{styles}</style><ForgotPage   onNavigate={setAuthPage} /></>;
    return <><style>{styles}</style><LoginPage onLogin={login} onNavigate={setAuthPage} /></>;
  }

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <DashboardPage />;
      case "analytics": return <AnalyticsPage />;
      case "crm":       return <CRMPage       toast={toast} />;
      case "finance":   return <FinancePage   toast={toast} />;
      case "projects":  return <ProjectsPage  toast={toast} />;
      case "kanban":    return <KanbanPage />;
      case "calendar":  return <CalendarPage  toast={toast} />;
      case "chat":      return <ChatPage />;
      case "email":     return <EmailPage     toast={toast} />;
      case "settings":  return <SettingsPage  toast={toast} />;
      default:          return <DashboardPage />;
    }
  };

  return (
    <>
      <style>{styles}</style>
      {/* Skip to main content — keyboard accessibility */}
      <a href="#main-content" className="skip-link">Skip to main content</a>
      <div className="app-shell">
        {mobileSidebar && (
          <div
            className="overlay"
            onClick={() => setMobileSidebar(false)}
            role="presentation"
            aria-hidden="true"
          />
        )}
        <Sidebar
          active={page}
          onNav={p => { setPage(p); setMobileSidebar(false); }}
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(p => !p)}
          mobileOpen={mobileSidebar}
          notifications={notifications}
        />
        <div className={`main-area${sidebarCollapsed ? " collapsed" : ""}`}>
          <Header
            onMenuToggle={() => {
              if (window.innerWidth <= 768) setMobileSidebar(p => !p);
              else setSidebarCollapsed(p => !p);
            }}
            page={page}
            darkMode={darkMode}
            toggleDark={() => setDarkMode(p => !p)}
            onLogout={logout}
            onNav={navigate}
            notifications={notifications}
            setNotifications={setNotifications}
          />
          <main id="main-content" className="page-content">
            {renderPage()}
          </main>
        </div>
      </div>
      <ToastContainer toasts={toasts} />
    </>
  );
}
